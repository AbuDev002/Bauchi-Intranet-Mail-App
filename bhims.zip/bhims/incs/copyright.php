<div class="text-center" style="color:#222; font-size:12px;margin-top:10px;margin-bottom: 10px;">Copyright &copy;
                                    <?php echo date('Y', time())?>
                                        Bauchi State of Nigeria - All right reserved.
                                            <br>Powered By <a href="http://www.gwanisoftware.com
" target="_blank" title="Developers" data-toggle="popover" data-trigger="hover" data-content="A product of Gwani Software" data-placement="bottom">Gwani Software</a></div>