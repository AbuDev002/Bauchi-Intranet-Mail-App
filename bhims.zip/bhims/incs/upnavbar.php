<hr>
<center>
<ul class="nav justify-content-center">
  
  	<li class="nav-item"><a  class="nav-link" href="notice_board.php"><i class="fa fa-info-circle"></i> Notice Board</a></li>
  	<li class="nav-item"><a  class="nav-link" href="HomePage.php?chk=archive"><i class="fa fa-archive"></i> Archive</a></li>
  	<li class="nav-item"><a  class="nav-link" href="profile_page.php"><i class="fa fa-user-circle-o"></i> Profile</a></li>
  	<li class="nav-item"><a  class="nav-link" href="users.php"><i class="fa fa-users"></i> Users</a></li>
    <?php if($_SESSION['account_type'] =='Superadmin'){?>
  	<li class="nav-item"><a  class="nav-link" href="access_logs.php">Access Logs</a></li>
  <?php } ?>
   <?php if($_SESSION['account_type'] =='Highleveladmin'){?>
    <li class="nav-item"><a  class="nav-link" href="manage_minutes">Manage Minutes</a></li>
  <?php } ?>
   <?php if($_SESSION['account_type'] =='Authenticator'){?>
    <li class="nav-item"><a  class="nav-link" href="manage_mails"><i class="fa fa-envelope-o"></i> Manage Mails</a></li>
  <?php } ?>
    <li class="nav-item"><a  class="nav-link" href="change_password.php"><i class="fa fa-lock"></i> Change Password </a></li>
  <!-- 	<li class="nav-item"><a  class="nav-link" href="chat.php"><i class="fa fa-comment"></i> Chat</a></li> -->
  	<li class="nav-item"><a  class="nav-link" href="logout.php"><i class="fa fa-fw fa-power-off"></i> Logout</a></li>
</ul>
</center>
<span onclick="openNav()"><i class="togler-menu fa fa-align-justify fa-lg" ></i></span>
<div id="mySidenav" class="sidenav" style="background-color: #50667F !important;opacity: 0.9">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="HomePage.php?chk=compose" class="btn btn-primary btn-block margin-bottom"><i class="fa fa-edit"></i>  Compose</a>
  <a href="HomePage.php?chk=inbox" class="list-group-item list-group-item-action"><i class="fa fa-inbox"></i> Inbox 
                <span class="label label-danger pull-right">
                 (<?php
                    include_once('connection.php');
                    $id=$_SESSION['email'];
                    $sql_getinbox="SELECT count(*) as totalinbox FROM usermail where rec_id='$id'";
                    $totalinbox=mysqli_query($conms,$sql_getinbox);
                    $row = mysqli_fetch_array($totalinbox);
                    echo $row['totalinbox'];
                  ?>)
              </span></a>
  <a href="HomePage.php?chk=sent" class="list-group-item list-group-item-action"><i class="fa fa-envelope-o"></i> Sent Mail <span class="label label-danger pull-right">
                 (<?php
                    include_once('connection.php');
                    $id=$_SESSION['email'];
                    $sql_getinbox="SELECT count(*) as totalinbox FROM usermail where sen_id='$id'";
                    $totalinbox=mysqli_query($conms,$sql_getinbox);
                    $row = mysqli_fetch_array($totalinbox);
                    echo $row['totalinbox'];
                  ?>)
              </span></a>
  <a href="HomePage.php?chk=draft" class="list-group-item list-group-item-action"><i class=" fa fa-external-link"></i> Drafts <span class="label label-danger pull-right">
                 (<?php
                    include_once('connection.php');
                    $id=$_SESSION['email'];
                    $sql_getinbox="SELECT count(*) as totalinbox FROM draft where user_id='$id'";
                    $totalinbox=mysqli_query($conms,$sql_getinbox);
                    $row = mysqli_fetch_array($totalinbox);
                    echo $row['totalinbox'];
                  ?>)
              </span></a>
   <a href="HomePage.php?chk=trash" class="list-group-item list-group-item-action"><i class=" fa fa-trash-o"></i> Trash</a>
</div>