<div role="navigation" class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
         
        </div>
        <div class="navbar-collapse collapse">
         
        </div><!--/.nav-collapse -->
      </div>
      <h5> <i class="fa fa-envelope"></i> Bauchi State Intranet Mailing System</h5>
</div>
<center><p class="alert alert-info" style="background-color:#f5f5f5;border-color: silver;"><?php echo "<strong>Welcome ".$_SESSION['name']." ::: ".$_SESSION['email']."</strong>";?></center></p>

<?php
	$mail = $_SESSION['email'];
	include_once("connection.php");
	$getexpiredate = mysqli_query($conms,"SELECT * FROM userinfo WHERE email= '$mail'");
	if(mysqli_num_rows($getexpiredate)> 0){
		$expireddate = mysqli_fetch_array($getexpiredate);
	}
	$todayDate = strtotime(date("Y-m-d"));
	$userRegDate = $expireddate['lastupdated'];
	$passwordExpiredDate = strtotime($userRegDate."+ 30 days");
	//compare todays date and Password expired date
	if($todayDate < $passwordExpiredDate){
		//product expired
		$datediff = $todayDate - $passwordExpiredDate;
		//How to check the remaining days
		$show = abs(floor($datediff / (60 * 60 * 24)));
		//if($show < 10){
		echo "<center><p class='text-warning'>Your password will expire in ".$show." days</p></center>";
		//}
	}else{
		$_SESSION['passwordexpired'] = "expired";
		header('location:passwordexpired.php');
		//echo "<center><p class='text-warning'>Your password has expired</p></center>";
	}

?>
