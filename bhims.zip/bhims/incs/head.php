<?php
    error_reporting(0);
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8" />
    <title>Bauchi State IMS - <?php echo $title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Bauchi State Intranet System">
    <meta name="author" content="Abubakar Muhammad">
    <link rel="icon" type="image/jpg" sizes="100x100" href="images/bhfav.jpg">

    <!-- External styles -->
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />
     <link rel="stylesheet" href="css/jquery-ui.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/datatable.min.css">
    <link rel="stylesheet" href="css/styles.css" />
    <link href="css/font.css" rel="stylesheet">
    <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>
<body bgcolor="#dedede">
     <div id="preloader">
        <div data-loader="circle-side"></div>
    </div>