<div class="col-md-2 small-menu-users" id="left_side_menu" style="min-height: 500px;margin-top:10px;padding-top: 10px;">
<a href="HomePage.php?chk=compose" class="btn btn-primary btn-block margin-bottom"><i class="fa fa-edit"></i>  Compose</a>
 <aside class="list-group sm-side" style="border:1px solid silver;"> 
      <ul class="inbox-nav inbox-divider" style="margin-bottom: 0px;">
          <li class="active">
              <a href="HomePage.php?chk=inbox" class="list-group-item list-group-item-action"><i class="fa fa-inbox"></i> Inbox 
                <span id="inboxcount" class="label label-danger pull-right"></span></a>
          </li>
          <li>
              <a href="HomePage.php?chk=sent" class="list-group-item list-group-item-action"><i class="fa fa-envelope-o"></i> Sent Mail <span id="sentcount" class="label label-danger pull-right"></span></a>
          </li>
         <!--  <li>
              <a href="#" class="list-group-item list-group-item-action"><i class="fa fa-bookmark-o"></i> Outbox</a>
          </li> -->
          <li>
              <a href="HomePage.php?chk=draft" class="list-group-item list-group-item-action"><i class=" fa fa-external-link"></i> Drafts <span id="countdraft" class="label label-danger pull-right"> </span></a>
                
             
          </li>
          <li>
              <a href="HomePage.php?chk=trash" class="list-group-item list-group-item-action"><i class=" fa fa-trash-o"></i> Trash</a>
          </li>
      </ul>
  </aside>
</div>