
    <script src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="js/icheck.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script  src="js/jquery-ui.js" type="text/livescript"></script>
    <script src="js/script.js"></script>
   <script type="text/javascript" src="js/datatable.js" ></script>
   <script type="text/javascript" src="js/mails.js" ></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('.custom_table').dataTable();
                load_data();
                //setInterval(function(){
                function load_data(query)
                {
                  
                  $.ajax({
                    url:"MailList.php",
                    method:"post",
                    data:{query:query},
                    success:function(data)
                    {
                      $('#loadmails').html(data);
                    }
                  });
                }
                 //},1000);
                $('#search_mail').keyup(function(){
                  var search = $(this).val();
                  if(search != '')
                  {
                    load_data(search);
                  }
                  else
                  {
                    load_data();      
                  }
                });
            } );
        </script>
     <script type="text/javascript">
        //this function is loading inbox count
       function loadInbox() {
          setInterval(function(){
                 var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                 document.getElementById("inboxcount").innerHTML = this.responseText;
                }
              };
              xhttp.open("GET", "countinbox.php", true);
              xhttp.send();
            },1000);
          }
          loadInbox();
        //this function is loading sent message count
         function loadSentItems() {
          setInterval(function(){
                 var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                 document.getElementById("sentcount").innerHTML = this.responseText;
                }
              };
              xhttp.open("GET", "countsentmsg.php", true);
              xhttp.send();
            },1000);
          }
          loadSentItems();
           //this function is used to count draft
         function loadDraft() {
          setInterval(function(){
                 var xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                 document.getElementById("countdraft").innerHTML = this.responseText;
                }
              };
              xhttp.open("GET", "countdraft.php", true);
              xhttp.send();
            },1000);
          }
          loadDraft();

          //this function getting list of mails
         // function loadMailList() {
         //  setInterval(function(){
         //         var xhttp = new XMLHttpRequest();
         //      xhttp.onreadystatechange = function() {
         //        if (this.readyState == 4 && this.status == 200) {
         //         document.getElementById("loadmails").innerHTML = this.responseText;
         //        }
         //      };
         //      xhttp.open("GET", "MailList.php", true);
         //      xhttp.send();
         //    },1000);
         //  }
         //  loadMailList();
     </script>
    <script type="text/javascript">
        $(window).on('load',function(){

        // $('.loaders').on('click',fucntion(){
        /* ===========================
        ========== Pre-Loader ========
        ============================*/
        var preLoader = $("#preloader");
        preLoader.fadeOut(600);
        // });
        });
    </script>
     
    <!-- Userlogin  -->
    <script type="text/javascript">
    $(document).ready(function ($) {
        setTimeout(function(){
        $("#load").hide();
        $("#result").show();

        }, 2000);
        });
        $('document').ready(function($){
          //apply opacity to form
          function loadopacity(v){
              if(v == 'On'){
                $('#user-login').css({
                  opacity:0.2
                });
              
              }else{
                $('#user-login').css({
                  opacity:0.9
                });
              }

            }
            /* validation */
            $("#user-login").validate({
                rules:
                    {
                        password: {
                            required: true,
                        },
                        email: {
                            required: true,
                        },
                    },
                messages:
                    {
                        password: "<span style='color: red'>Password is required.</span>",
                        email: "<span style='color: red'>Email is required.</span>",
                    },
                submitHandler: submitForm
            });
            /* validation */

            /* login submit */
            function submitForm(){
                var data = $("#user-login").serialize();
                $.ajax({	
                    type : 'POST',
                    url  : "checklogin.php",
                    data : data,
                    beforeSend: function()
                    {
                        loadopacity('On');
                        $("#error").fadeOut();
                        $("#working").html('<button class="btn btn-primary btn-block login" ><strong class="block" style="font-weight: bold;">  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>  Verifying.... </strong></button>');
                    },
                    success :  function(response)
                    {
                        //loadopacity('On');
                        if(response=="Highleveladmin"){

                            $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting to mailbox...</button>');
                            setTimeout(' window.location.href = "HomePage.php"; ',2000);
                        }else if(response=="Middleleveladmin"){
                             $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting to mailbox...</button>');
                            setTimeout(' window.location.href = "HomePage.php"; ',2000);
                        }else if(response=="Lowleveladmin"){
                             $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting to mailbox...</button>');
                            setTimeout(' window.location.href = "HomePage.php"; ',2000);
                        }else if(response=="Authenticator"){
                             $("#working").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting to mailbox...</button>');
                            setTimeout(' window.location.href = "HomePage.php"; ',2000);
                        }else if(response=="Superadmin"){
                             $("#error").fadeIn(5000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>Please goto administrator area</div>');
                                $("#working").html('<button class="btn btn-primary btn-block login" id="working">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                loadopacity('Off');
                            });
                        }else{
                           
                            $("#error").fadeIn(1000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                                $("#working").html('<button class="btn btn-primary btn-block login" id="working">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                 loadopacity('Off');
                            });
                             if(response=="Your password has expired."){
                            setTimeout(' window.location.href = "passwordexpired.php"; ',2000);
                        }

                        }
                    },
                    error :  function(response)
                    {
                        
                        $("#error").fadeIn(1000, function(){
                            $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                            $("#working").html('');
                           
                        });
                         //loadopacity('Off');
                    }

                });
                return false;
            }
            /* login submit */
        });
    </script>
    <!-- administrator login -->
  <script type="text/javascript">
    $(document).ready(function ($) {
        setTimeout(function(){
        $("#load").hide();
        $("#result").show();

        }, 2000);
        });
        $('document').ready(function($){
            /* validation */
             //apply opacity to form
          function loadadminopacity(v){
              if(v == 'On'){
                $('#admin-login').css({
                  opacity:0.2
                });
              
              }else{
                $('#admin-login').css({
                  opacity:0.9
                });
              }

            }
            $("#admin-login").validate({
                rules:
                    {
                        password: {
                            required: true,
                        },
                        email: {
                            required: true,
                        },
                    },
                messages:
                    {
                        password: "<span style='color: red'>Password is required.</span>",
                        email: "<span style='color: red'>Email is required.</span>",
                    },
                submitHandler: submitForm
            });
            /* validation */

            /* login submit */
            function submitForm(){
                var data = $("#admin-login").serialize();
                $.ajax({
                    type : 'POST',
                    url  : "checklogin.php",
                    data : data,
                    beforeSend: function()
                    {
                        loadadminopacity('On');
                        $("#error").fadeOut();
                        $("#admworking").html('<button class="btn btn-primary btn-block login" ><strong class="block" style="font-weight: bold;">  <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>  Verifying.... </strong></button>');
                    },
                    success :  function(response)
                    {
                         if(response=="Highleveladmin"){
                           $("#error").fadeIn(2000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>Only admin can login here</div>');
                                $("#admworking").html('<button class="btn btn-primary btn-block login" id="admworking">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                loadadminopacity('Off');
                            });
                        }else if(response=="Middleleveladmin"){
                               $("#error").fadeIn(2000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>Only admin can login here</div>');
                                $("#admworking").html('<button class="btn btn-primary btn-block login" id="admworking">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                loadadminopacity('Off');
                            });
                        }else if(response=="Lowleveladmin"){
                              $("#error").fadeIn(2000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>Only admin can login here</div>');
                                $("#admworking").html('<button class="btn btn-primary btn-block login" id="admworking">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                loadadminopacity('Off');
                            });
                        }else if(response=="Authenticator"){
                            $("#error").fadeIn(2000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>Only admin can login here</div>');
                                $("#admworking").html('<button class="btn btn-primary btn-block login" id="admworking">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                loadadminopacity('Off');
                            });
                        }else if(response=="Superadmin"){
                                 $("#admworking").html('<button class="btn btn-primary btn-block login"> <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Success! redirecting to mailbox...</button>');
                                   setTimeout(' window.location.href = "HomePage.php"; ',2000);
                        }else{
                           
                            $("#error").fadeIn(1000, function(){
                                $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                                $("#admworking").html('<button class="btn btn-primary btn-block login" id="admworking">Login <i class="fa fa-sign-in fa-lg fa-fw"></i></button>');
                                 loadadminopacity('Off');
                            });
                             if(response=="Your password has expired."){
                            setTimeout(' window.location.href = "passwordexpired.php"; ',2000);
                        }

                        }
                    },
                    error :  function(response)
                    {
                        $("#error").fadeIn(1000, function(){
                            $("#error").html('<div class="alert alert-dismissible alert-danger"><button class="close" type="button" data-dismiss="alert">×</button>'+response+'</div>');
                            $("#admworking").html('');
                        });

                    }

                });
                return false;
            }
            /* login submit */
        });
    </script>
    <script type="text/javascript">
            /* Open the sidenav */
            function openNav() {
              document.getElementById("mySidenav").style.width = "100%";
            }

            /* Close/hide the sidenav */
            function closeNav() {
              document.getElementById("mySidenav").style.width = "0";
            }
        </script>
        <script type="text/javascript">
             //Enable check and uncheck all functionality
            $(".checkbox-toggle").click(function () {
              var clicks = $(this).data('clicks');
              if (clicks) {
                //Uncheck all checkboxes
                $(".mail-checkbox").iCheck("uncheck");
                $(".fa", this).removeClass("fa-check-square-o").addClass('fa-square-o');
              } else {
                //Check all checkboxes
                $(".mail-checkbox").iCheck("check");
                $(".fa", this).removeClass("fa-square-o").addClass('fa-check-square-o');
              }
              $(this).data("clicks", !clicks);
            });
        </script>
       
</body>
</html>