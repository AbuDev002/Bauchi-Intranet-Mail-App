<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Notice Board";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
						<?php if($_SESSION['account_type'] =="Superadmin"){?>
							<center><a href="add_notice.php" class="btn btn-primary margin-bottom"><i class="fa fa-plus"></i>Add To Notice Board</a></center>
						<?php }?>
					  <h3>Notice Board</h3>
					  <hr>
					  <?php 
					  		include_once('connection.php');
							$getpost_sql ="SELECT * FROM notice ORDER BY notie_id DESC";
							$getpost_qry = mysqli_query($conms,$getpost_sql);
							while($getpost_rs = mysqli_fetch_array($getpost_qry)){
						?>
						<div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;">
							<h4><?php echo $getpost_rs['subject'];?></h4>
							<p style="text-align:justify;"><?php echo $getpost_rs['notice_content'];?></p>
						<?php if($_SESSION['account_type'] =='Superadmin'){?>
							<p><a href="del_notice.php?del=<?php echo $getpost_rs['notie_id'];?>"><i class="fa fa-trash" onclick="return confirm('Are you sure to delete?');"></i></a></p>
						<?php } ?>
						</div>
					<?php } ?>
					</div>
						
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>