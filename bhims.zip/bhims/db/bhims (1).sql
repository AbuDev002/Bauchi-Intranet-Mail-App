-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2020 at 12:40 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bhims`
--

-- --------------------------------------------------------

--
-- Table structure for table `archives`
--

CREATE TABLE IF NOT EXISTS `archives` (
  `archive_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `attach` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `archivedate` date NOT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `archives`
--

INSERT INTO `archives` (`archive_id`, `user_id`, `sub`, `attach`, `msg`, `archivedate`) VALUES
(1, 'comissioner@bh.gov.ng', 'Ramadan Greatings', '', '<p>Dear Sir,</p>\r\n\r\n<p>As we are approaching Ramadan fasting. we pray Allah to make us among the forgiven individuals in this bless month</p>\r\n', '2020-04-19'),
(2, 'comissioner@bh.gov.ng', 'THe watermark image for testng', 'uploads/offdocuments/2fac72800b.jpg', '<p>This is a testing message for water mark image. Successful</p>\r\n', '2020-04-09'),
(4, 'comissioner@bh.gov.ng', 'Request for Lockdown', 'uploads/offdocuments/56e362d380.jpg', '<p>Dear Sir,</p>\r\n\r\n<p>Request for lockdown in the state due to increase in number of covid 19.</p>\r\n\r\n<p>Regards.</p>\r\n', '2020-04-20'),
(5, 'comissioner@bh.gov.ng', 'Request for Lockdown', 'uploads/offdocuments/56e362d380.jpg', '<p>Dear Sir,</p>\r\n\r\n<p>Request for lockdown in the state due to increase in number of covid 19.</p>\r\n\r\n<p>Regards.</p>\r\n', '2020-04-20'),
(6, 'comissioner@bh.gov.ng', 'xzbxfdfnd', 'uploads/offdocuments/2d7cac4258.jpg', '<p>Image iamge iamge image</p>\r\n', '2020-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `draft`
--

CREATE TABLE IF NOT EXISTS `draft` (
  `draft_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `attach` varchar(200) NOT NULL,
  `msg` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`draft_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `img_id` int(11) NOT NULL AUTO_INCREMENT,
  `imagepath` varchar(200) NOT NULL,
  PRIMARY KEY (`img_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `latestupd`
--

CREATE TABLE IF NOT EXISTS `latestupd` (
  `upd_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`upd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `logging_history`
--

CREATE TABLE IF NOT EXISTS `logging_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logindate` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `time_in` varchar(100) NOT NULL,
  `time_out` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=142 ;

--
-- Dumping data for table `logging_history`
--

INSERT INTO `logging_history` (`id`, `logindate`, `email`, `name`, `time_in`, `time_out`) VALUES
(1, '2020-04-08', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '07:34:46', '10:02:15'),
(2, '2020-04-08', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '07:43:31', '10:02:15'),
(3, '2020-04-08', 'staff@bh.gov.ng', 'Staff', '07:45:22', '10:33:44'),
(4, '2020-04-08', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '07:48:35', '10:02:15'),
(5, '2020-04-08', 'staff@bh.gov.ng', 'Staff', '07:58:21', '10:33:44'),
(6, '2020-04-08', 'staff@bh.gov.ng', 'Staff', '08:04:41', '10:33:44'),
(7, '2020-04-08', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '08:06:13', '10:02:15'),
(8, '2020-04-08', 'superadmin@bh.gov.ng', 'His Excellency', '11:40:34', '12:38:33'),
(9, '2020-04-08', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '11:41:16', '10:37:32'),
(10, '2020-04-08', 'superadmin@bh.gov.ng', 'His Excellency', '11:42:49', '12:38:33'),
(11, '2020-04-08', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '11:46:58', '10:43:41'),
(12, '2020-04-08', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '11:47:40', '10:37:32'),
(13, '2020-04-08', 'superadmin@bh.gov.ng', 'His Excellency', '20:47:55', '12:38:33'),
(14, '2020-04-09', 'superadmin@bh.gov.ng', 'His Excellency', '08:19:21', '12:38:33'),
(15, '2020-04-09', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '08:35:43', '10:37:32'),
(16, '2020-04-09', 'superadmin@bh.gov.ng', 'His Excellency', '08:36:29', '12:38:33'),
(17, '2020-04-09', 'staff@bh.gov.ng', 'Staff', '08:42:32', '10:33:44'),
(18, '2020-04-09', 'staff@bh.gov.ng', 'Staff', '09:41:49', '10:33:44'),
(19, '2020-04-09', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:53:12', '10:02:15'),
(20, '2020-04-09', 'superadmin@bh.gov.ng', 'His Excellency', '12:42:19', '12:38:33'),
(21, '2020-04-15', 'superadmin@bh.gov.ng', 'His Excellency', '07:47:11', '12:38:33'),
(22, '2020-04-15', 'superadmin@bh.gov.ng', 'His Excellency', '07:47:38', '12:38:33'),
(23, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '07:56:52', '10:33:44'),
(24, '2020-04-19', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:00:40', '10:02:15'),
(25, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '12:02:15', '10:33:44'),
(26, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '12:11:49', '10:33:44'),
(27, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '12:18:55', '10:33:44'),
(28, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '12:21:09', '10:33:44'),
(29, '2020-04-19', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '16:24:56', '10:37:32'),
(30, '2020-04-19', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '16:26:00', '10:02:15'),
(31, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '20:30:06', '10:33:44'),
(32, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '20:30:41', '10:33:44'),
(33, '2020-04-19', 'superadmin@bh.gov.ng', 'His Excellency', '20:31:38', '12:38:33'),
(34, '2020-04-19', 'staff@bh.gov.ng', 'Staff', '20:41:17', '10:33:44'),
(35, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:03:28', '10:02:15'),
(36, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:39:54', '10:02:15'),
(37, '2020-04-20', 'staff@bh.gov.ng', 'Staff', '09:41:57', '10:33:44'),
(38, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:43:37', '10:02:15'),
(39, '2020-04-20', 'superadmin@bh.gov.ng', 'His Excellency', '09:56:04', '12:38:33'),
(40, '2020-04-20', 'staff@bh.gov.ng', 'Staff', '09:57:32', '10:33:44'),
(41, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:00:41', '10:02:15'),
(42, '2020-04-20', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '10:01:27', '10:43:41'),
(43, '2020-04-20', 'pps@bh.gov.ng', 'PPS', '10:02:22', '10:03:25'),
(44, '2020-04-20', 'superadmin@bh.gov.ng', 'His Excellency', '10:03:25', '12:38:33'),
(45, '2020-04-20', 'pps@bh.gov.ng', 'PPS', '10:04:18', '10:03:25'),
(46, '2020-04-20', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '10:06:03', '10:43:41'),
(47, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:06:45', '10:02:15'),
(48, '2020-04-20', 'staff@bh.gov.ng', 'Staff', '10:07:23', '10:33:44'),
(49, '2020-04-20', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:16:37', '10:02:15'),
(50, '2020-04-22', 'staff@bh.gov.ng', 'Staff', '11:47:58', '10:33:44'),
(51, '2020-04-22', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '11:48:41', '10:02:15'),
(52, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '12:50:48', '10:37:32'),
(53, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '13:02:50', '12:38:33'),
(54, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '13:04:20', '10:37:32'),
(55, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '13:12:08', '12:38:33'),
(56, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '13:13:01', '10:37:32'),
(57, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '13:13:39', '12:38:33'),
(58, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '13:15:16', '10:37:32'),
(59, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '13:16:07', '12:38:33'),
(60, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '13:24:20', '10:37:32'),
(61, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '13:33:36', '12:38:33'),
(62, '2020-05-05', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '13:36:44', '10:37:32'),
(63, '2020-05-05', 'staff@bh.gov.ng', 'Staff', '13:53:56', '10:33:44'),
(64, '2020-05-05', 'staff@bh.gov.ng', 'Staff', '15:01:10', '10:33:44'),
(65, '2020-05-05', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '15:15:22', '10:02:15'),
(66, '2020-05-05', 'pps@bh.gov.ng', 'PPS', '22:31:53', '10:03:25'),
(67, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '22:32:40', '12:38:33'),
(68, '2020-05-05', 'pps@bh.gov.ng', 'PPS', '22:40:05', '10:03:25'),
(69, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '22:43:55', '12:38:33'),
(70, '2020-05-05', 'superadmin@bh.gov.ng', 'His Excellency', '22:44:35', '12:38:33'),
(71, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:25:26', '12:38:33'),
(72, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:25:43', '10:03:25'),
(73, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:27:26', '12:38:33'),
(74, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:30:12', '12:38:33'),
(75, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:40', '10:03:25'),
(76, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:44', '10:03:25'),
(77, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:45', '10:03:25'),
(78, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:46', '10:03:25'),
(79, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:47', '10:03:25'),
(80, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:48', '10:03:25'),
(81, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:30:49', '10:03:25'),
(82, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:32:46', '10:03:25'),
(83, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:34:38', '10:03:25'),
(84, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:34:54', '10:03:25'),
(85, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:41:39', '10:03:25'),
(86, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:44:57', '10:03:25'),
(87, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:44:59', '10:03:25'),
(88, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:00', '10:03:25'),
(89, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:01', '10:03:25'),
(90, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:02', '10:03:25'),
(91, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:03', '10:03:25'),
(92, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:03', '10:03:25'),
(93, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:06', '10:03:25'),
(94, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:45:46', '10:03:25'),
(95, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:46:06', '12:38:33'),
(96, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:49:58', '10:03:25'),
(97, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:52:02', '10:03:25'),
(98, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:53:59', '10:03:25'),
(99, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:56:23', '12:38:33'),
(100, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:56:36', '12:38:33'),
(101, '2020-05-06', 'superadmin@bh.gov.ng', 'His Excellency', '09:57:03', '12:38:33'),
(102, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '09:57:20', '10:03:25'),
(103, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '10:00:23', '10:03:25'),
(104, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '10:02:30', '10:03:25'),
(105, '2020-05-06', 'pps@bh.gov.ng', 'PPS', '10:02:54', '10:03:25'),
(106, '2020-05-06', 'staff@bh.gov.ng', 'Staff', '10:03:35', '10:33:44'),
(107, '2020-05-06', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:06:34', '10:02:15'),
(108, '2020-05-06', 'staff@bh.gov.ng', 'Staff', '10:08:17', '10:33:44'),
(109, '2020-05-06', 'staff@bh.gov.ng', 'Staff', '13:07:50', '10:33:44'),
(110, '2020-05-06', 'staff@bh.gov.ng', 'Staff', '13:10:31', '10:33:44'),
(111, '2020-05-07', 'staff@bh.gov.ng', 'Staff', '09:09:37', '10:33:44'),
(112, '2020-05-07', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '09:49:46', '10:02:15'),
(113, '2020-05-07', 'staff@bh.gov.ng', 'Staff', '09:57:00', '10:33:44'),
(114, '2020-05-07', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:12:27', '10:02:15'),
(115, '2020-05-07', 'superadmin@bh.gov.ng', 'His Excellency', '10:19:28', '12:38:33'),
(116, '2020-05-07', 'staff@bh.gov.ng', 'Staff', '12:29:34', '10:33:44'),
(117, '2020-05-07', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '12:44:20', '10:02:15'),
(118, '2020-05-07', 'staff@bh.gov.ng', 'Staff', '13:16:54', '10:33:44'),
(119, '2020-05-07', 'superadmin@bh.gov.ng', 'His Excellency', '13:17:20', '12:38:33'),
(120, '2020-05-07', 'staff@bh.gov.ng', 'Staff', '13:18:01', '10:33:44'),
(121, '2020-05-08', 'staff@bh.gov.ng', 'Staff', '09:56:26', '10:33:44'),
(122, '2020-05-08', 'comissioner@bh.gov.ng', 'Comissioner of FInance', '10:01:04', '10:02:15'),
(123, '2020-05-08', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '10:02:31', '10:43:41'),
(124, '2020-05-08', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '10:04:23', '10:37:32'),
(125, '2020-05-08', 'superadmin@bh.gov.ng', 'His Excellency', '10:06:04', '12:38:33'),
(126, '2020-05-08', 'staff@bh.gov.ng', 'Staff', '10:19:26', '10:33:44'),
(127, '2020-05-08', 'superadmin@bh.gov.ng', 'His Excellency', '10:26:17', '12:38:33'),
(128, '2020-05-08', 'staff@bh.gov.ng', 'Staff', '10:33:28', '10:33:44'),
(129, '2020-05-08', 'superadmin@bh.gov.ng', 'His Excellency', '10:33:58', '12:38:33'),
(130, '2020-05-08', 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '10:37:20', '10:37:32'),
(131, '2020-05-08', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '10:37:53', '10:43:41'),
(132, '2020-05-08', 'staff@bh.gov.ng', 'Staff', '10:44:24', 'Not Available'),
(133, '2020-05-08', 'staff@bh.gov.ng', 'Staff', '23:18:21', 'Not Available'),
(134, '2020-05-08', 'superadmin@bh.gov.ng', 'His Excellency', '23:18:36', '12:38:33'),
(135, '2020-05-09', 'staff@bh.gov.ng', 'Staff', '10:48:27', 'Not Available'),
(136, '2020-05-09', 'superadmin@bh.gov.ng', 'His Excellency', '10:55:27', '12:38:33'),
(137, '2020-05-09', 'staff@bh.gov.ng', 'Staff', '12:54:11', 'Not Available'),
(138, '2020-05-09', 'superadmin@bh.gov.ng', 'His Excellency', '12:55:46', '12:38:33'),
(139, '2020-05-27', 'superadmin@bh.gov.ng', 'His Excellency', '15:58:09', '12:38:33'),
(140, '2020-06-10', 'superadmin@bh.gov.ng', 'His Excellency', '12:36:29', '12:38:33'),
(141, '2020-06-10', 'superadmin@bh.gov.ng', 'His Excellency', '12:37:59', '12:38:33');

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(50) NOT NULL,
  `sen_id` varchar(50) NOT NULL,
  `sub` char(50) NOT NULL,
  `msg` text NOT NULL,
  `draft` text NOT NULL,
  `trash` text NOT NULL,
  `attachement` varchar(200) NOT NULL,
  `msgdate` varchar(50) NOT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mails_access_history`
--

CREATE TABLE IF NOT EXISTS `mails_access_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dateofaccess` varchar(100) NOT NULL,
  `accesstime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `mails_access_history`
--

INSERT INTO `mails_access_history` (`id`, `email`, `name`, `dateofaccess`, `accesstime`) VALUES
(1, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-08', '07:57:56'),
(2, 'staff@bh.gov.ng', 'Staff', '2020-04-08', '08:00:19'),
(3, 'superadmin@bh.gov.ng', 'His Excellency', '2020-04-08', '11:43:05'),
(4, 'superadmin@bh.gov.ng', 'His Excellency', '2020-04-08', '11:45:39'),
(5, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-08', '11:50:56'),
(6, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-08', '11:53:43'),
(7, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-08', '11:54:52'),
(8, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-08', '11:59:57'),
(9, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-08', '12:00:10'),
(10, 'superadmin@bh.gov.ng', 'His Excellency', '2020-04-09', '08:05:07'),
(11, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-04-09', '08:36:01'),
(12, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-09', '12:38:05'),
(13, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-09', '12:38:30'),
(14, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-09', '12:40:27'),
(15, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-19', '09:01:59'),
(16, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-19', '09:03:17'),
(17, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-19', '16:26:42'),
(18, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-19', '16:29:36'),
(19, 'staff@bh.gov.ng', 'Staff', '2020-04-19', '20:30:58'),
(20, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-20', '09:47:08'),
(21, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-20', '10:00:51'),
(22, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-20', '10:01:08'),
(23, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-04-20', '10:01:33'),
(24, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-04-20', '10:02:08'),
(25, 'pps@bh.gov.ng', 'PPS', '2020-04-20', '10:02:29'),
(26, 'pps@bh.gov.ng', 'PPS', '2020-04-20', '10:03:06'),
(27, 'superadmin@bh.gov.ng', 'His Excellency', '2020-04-20', '10:03:33'),
(28, 'superadmin@bh.gov.ng', 'His Excellency', '2020-04-20', '10:04:00'),
(29, 'pps@bh.gov.ng', 'PPS', '2020-04-20', '10:05:30'),
(30, 'pps@bh.gov.ng', 'PPS', '2020-04-20', '10:05:43'),
(31, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-04-20', '10:06:15'),
(32, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-04-20', '10:06:29'),
(33, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-20', '10:06:51'),
(34, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-20', '10:07:01'),
(35, 'staff@bh.gov.ng', 'Staff', '2020-04-20', '10:13:09'),
(36, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-04-22', '12:14:03'),
(37, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-05', '13:13:52'),
(38, 'staff@bh.gov.ng', 'Staff', '2020-05-05', '15:08:12'),
(39, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-05-05', '15:40:13'),
(40, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-05-05', '15:40:23'),
(41, 'staff@bh.gov.ng', 'Staff', '2020-05-07', '09:09:57'),
(42, 'staff@bh.gov.ng', 'Staff', '2020-05-07', '09:10:21'),
(43, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-05-07', '12:47:05'),
(44, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-05-08', '10:01:44'),
(45, 'comissioner@bh.gov.ng', 'Comissioner of FInance', '2020-05-08', '10:02:10'),
(46, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-05-08', '10:03:15'),
(47, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-05-08', '10:03:50'),
(48, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-05-08', '10:05:07'),
(49, 'chiefofstaff@bh.gov.ng', 'Chief of Staff', '2020-05-08', '10:05:47'),
(50, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:26:33'),
(51, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:28:30'),
(52, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:29:11'),
(53, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:29:56'),
(54, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:32:03'),
(55, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:33:09'),
(56, 'staff@bh.gov.ng', 'Staff', '2020-05-08', '10:33:39'),
(57, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:34:12'),
(58, 'superadmin@bh.gov.ng', 'His Excellency', '2020-05-08', '10:35:45'),
(59, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-05-08', '10:38:03');

-- --------------------------------------------------------

--
-- Table structure for table `minutes_quotes`
--

CREATE TABLE IF NOT EXISTS `minutes_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minute_text` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `minutes_quotes`
--

INSERT INTO `minutes_quotes` (`id`, `minute_text`) VALUES
(1, 'KIV'),
(2, 'Discuss'),
(3, 'Approve'),
(4, 'Refer'),
(5, 'ODE'),
(6, 'BU'),
(7, 'FYA'),
(8, 'Not Approve');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
  `notie_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(50) NOT NULL,
  `notice_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notice_content` text NOT NULL,
  `postedby` varchar(100) NOT NULL,
  PRIMARY KEY (`notie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `trash`
--

CREATE TABLE IF NOT EXISTS `trash` (
  `trash_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(50) NOT NULL,
  `sen_id` varchar(50) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `msg` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`trash_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `trash`
--

INSERT INTO `trash` (`trash_id`, `rec_id`, `sen_id`, `sub`, `msg`, `date`) VALUES
(4, 'pps@bh.gov.ng', 'superadmin@bh.gov.ng', 'Hello pps', '<p>Hello pps how are you</p>\r\n', '2020-04-02 19:26:12'),
(34, 'comissioner@bh.gov.ng', 'staff@bh.gov.ng', 'dfhdgjhf', '<p>zxfbxhcvncbmvn</p>\r\n', '2020-05-05 13:04:42'),
(33, 'comissioner@bh.gov.ng', 'staff@bh.gov.ng', 'safgsdfgsdf', '<p>adsfasdfasdgdfsgdfsg</p>\r\n', '2020-05-05 13:04:32'),
(32, 'pps@bh.gov.ng', 'superadmin@bh.gov.ng', 'Request for Lockdown', '<p>Dear Sir,</p>\r\n\r\n<p>Request for lockdown in the state due to increase in number of covid 19.</p>\r\n\r\n<p>Regards.</p>\r\n', '2020-05-05 11:12:29'),
(31, 'superadmin@bh.gov.ng', 'chiefofstaff@bh.gov.ng', 'dfagshdfg', '<p>dsfgsdgsgsdfg</p>\r\n', '2020-05-05 11:11:45'),
(30, 'superadmin@bh.gov.ng', 'chiefofstaff@bh.gov.ng', 'asfdgsdf', '<p>asdgsdfgssgsfgs</p>\r\n', '2020-05-05 11:10:26'),
(29, 'superadmin@bh.gov.ng', 'chiefofstaff@bh.gov.ng', 'sdfasdf', '<p>asdsdfgdsfgsdfgsdfg</p>\r\n', '2020-05-05 11:08:41'),
(27, '--Send To--', 'comissioner@bh.gov.ng', 'it make sense', '<p>is alos make sense</p>\r\n', '2020-04-22 10:01:56'),
(28, 'superadmin@bh.gov.ng', 'chiefofstaff@bh.gov.ng', 'Testing stamped message', '<p>Your excellency sir,</p>\r\n\r\n<p>This is your image with stamped</p>\r\n', '2020-05-05 11:04:33'),
(26, 'docauthenticator@bh.gov.ng', 'comissioner@bh.gov.ng', 'Request for Lockdown', '<p>Dear Sir,</p>\r\n\r\n<p>Request for lockdown in the state due to increase in number of covid 19.</p>\r\n\r\n<p>Regards.</p>\r\n', '2020-04-22 10:01:47'),
(25, '--Send To--', 'staff@bh.gov.ng', 'The water mark image is going', '<p>THe government house files will contain a water mark image for uniqueness</p>\r\n', '2020-04-09 07:45:52');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `account_type` varchar(100) NOT NULL,
  `block` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(100) NOT NULL,
  `lastlogin` varchar(100) NOT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`username`,`mobile`,`email`),
  KEY `gender` (`gender`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`name`, `username`, `password`, `mobile`, `email`, `gender`, `image`, `account_type`, `block`, `sid`, `lastlogin`, `lastupdated`, `user_id`) VALUES
('His Excellency', 'superadmin', '5f4dcc3b5aa765d61d8327deb882cf99', '--', 'superadmin@bh.gov.ng', 'Male', '', 'Superadmin', 0, '4643f55804fc9f1768ef11a9b924f658', '2020-06-10 11:37:59', '2020-06-10 10:37:59', 0001),
('Chief of Staff', 'chiefofstaff', '5f4dcc3b5aa765d61d8327deb882cf99', '--', 'chiefofstaff@bh.gov.ng', 'Male', '', 'Highleveladmin', 0, '54088c5edeeb8000e28268d2d7fc7da0', '2020-05-08 09:37:20', '2020-05-08 08:37:20', 0002),
('PPS', 'pps', '5f4dcc3b5aa765d61d8327deb882cf99', '--', 'pps@bh.gov.ng', 'Male', '', 'Highleveladmin', 0, 'ee782b6fe382ff874a3cd036d6ef5f37', '2020-05-06 09:02:54', '2020-05-06 08:02:54', 0003),
('Document Verification Officer', 'docauthenticator', '5f4dcc3b5aa765d61d8327deb882cf99', '--', 'docauthenticator@bh.gov.ng', 'Male', '', 'Authenticator', 0, 'd007e641083e42d53fe04a2932275bae', '2020-05-08 09:37:53', '2020-05-08 08:37:53', 0004),
('Comissioner of FInance', 'comissioner', '5f4dcc3b5aa765d61d8327deb882cf99', '08025569874', 'comissioner@bh.gov.ng', 'Male', '', 'Middleleveladmin', 0, '446df5a96895af1b6c2996fb1f7482c4', '2020-05-08 09:01:04', '2020-05-08 08:01:04', 0005),
('Staff', 'Staff', '5f4dcc3b5aa765d61d8327deb882cf99', 'nill', 'staff@bh.gov.ng', 'Male', '', 'Lowleveladmin', 0, 'eae5d071d7781e6dbc5593f7b0925b50', '2020-05-09 11:54:11', '2020-05-09 10:54:11', 0006);

-- --------------------------------------------------------

--
-- Table structure for table `usermail`
--

CREATE TABLE IF NOT EXISTS `usermail` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(30) NOT NULL,
  `sen_id` varchar(30) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `attachement` text NOT NULL,
  `minute_quote` varchar(100) NOT NULL,
  `minuteby` varchar(100) NOT NULL,
  `sentby` varchar(100) NOT NULL,
  `mailtype` varchar(100) NOT NULL,
  `seenstatus` int(11) NOT NULL DEFAULT '0',
  `recDT` date NOT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `usermail`
--

INSERT INTO `usermail` (`mail_id`, `rec_id`, `sen_id`, `sub`, `msg`, `attachement`, `minute_quote`, `minuteby`, `sentby`, `mailtype`, `seenstatus`, `recDT`) VALUES
(1, 'comissioner@bh.gov.ng', 'staff@bh.gov.ng', 'Testing Watermark on image file', '<p>Dear Sir,</p>\r\n\r\n<p>This is just a watermark test on pdf file.</p>\r\n\r\n<p>Regards.</p>\r\n', 'uploads/offdocuments/a7c11ec1ff.jpg', '', '', 'Lowleveladmin', 'normalmail', 0, '2020-05-08'),
(2, 'comissioner@bh.gov.ng', 'staff@bh.gov.ng', 'Testing watermark image on pdf file', '<p>Dear sir.</p>\r\n\r\n<p>This is a pdf file for watermark testing and user id.</p>\r\n\r\n<p>Regards.</p>\r\n', 'uploads/offdocuments/5b4648aa9d.pdf', 'Dear sir, Please verify this document and forward.', 'Comissioner of FInance', 'Lowleveladmin', 'normalmail', 1, '2020-05-08'),
(3, 'docauthenticator@bh.gov.ng', 'comissioner@bh.gov.ng', 'Testing watermark image on pdf file', '<p>Dear sir.</p>\r\n\r\n<p>This is a pdf file for watermark testing and user id.</p>\r\n\r\n<p>Regards.</p>\r\n', 'uploads/offdocuments/5b4648aa9d.pdf', 'Hello Sir, Please we seek for you input regarding this. Thanks', 'Document Verification Officer', 'Middleleveladmin', 'normalmail', 1, '2020-05-08'),
(4, 'chiefofstaff@bh.gov.ng', 'docauthenticator@bh.gov.ng', 'Testing watermark image on pdf file', '<p>Dear sir.</p>\r\n\r\n<p>This is a pdf file for watermark testing and user id.</p>\r\n\r\n<p>Regards.</p>\r\n', 'uploads/offdocuments/5b4648aa9d.pdf', 'Your excellency sir, we seek for your kind approval and recommendation regarding this. Thank you', 'Chief of Staff', 'Authenticator', 'normalmail', 1, '2020-05-08'),
(5, 'superadmin@bh.gov.ng', 'chiefofstaff@bh.gov.ng', 'Testing watermark image on pdf file', '<p>Dear sir.</p>\r\n\r\n<p>This is a pdf file for watermark testing and user id.</p>\r\n\r\n<p>Regards.</p>\r\n', 'uploads/offdocuments/5b4648aa9d.pdf', 'Your excellency sir, we seek for your kind approval and recommendation regarding this. Thank you', 'Chief of Staff', 'Highleveladmin', 'normalmail', 1, '2020-05-08'),
(6, 'docauthenticator@bh.gov.ng', 'superadmin@bh.gov.ng', 'Request for files verfication', '<p>Hello sir,</p>\r\n\r\n<p>Are you done with the file verification.</p>\r\n\r\n<p>Regards.</p>\r\n', '', '', '', 'Superadmin', 'specialmail', 1, '2020-05-08');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
