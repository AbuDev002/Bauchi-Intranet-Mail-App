<?php
	function output_errors($error){
		return '<ul><li>'.implode('</li><li>', $error).'</li></ul>';
	}

	function logged_in(){
		return(!isset($_SESSION['username']))? true : false;
	}
	
	function user_exist($username){
		$username = mysql_real_escape_string($username);
		$query = mysql_query("SELECT COUNT('id') from employee WHERE username='$username'");
			return(mysql_result($query, 0)== 1)? true : false;
	}
	
	function get_userid_from_user($username){
		$username = mysql_real_escape_string($username);
		return mysql_result(mysql_query("SELECT id FROM employee WHERE username='$username'"),0,'id');
	
	}
	
	
	/*function user_login($username, $password, $account_type){
		 $user_id = get_userid_from_user($username);
		 
		$username = mysql_real_escape_string($username);
		$password = md5($password);
		$account_type = mysql_real_escape_string($account_type);
		
			$lquery = mysql_query("SELECT COUNT('id') FROM employee WHERE username='$username',password='$password' AND account_type='$account_type'");
			
			return(mysql_result($lquery, 0) ==1)? $user_id : false;
	
	}*/
	
	function add_post($title,$content, $category){
		$title = mysql_real_escape_string($title);
		$content = mysql_real_escape_string($content);
		$category = (int)$category;
		
		$q="INSERT INTO posts SET cat_id =$category, title='$title', content='$content', date_posted= NOW()";
			$q_r =mysql_query($q);
		
		return $q_r;
					
	}
	
	function edit_post($id,$title,$content, $category){
		$title = mysql_real_escape_string($title);
		$content = mysql_real_escape_string($content);
		$category = (int)$category;
		
		$eq="UPDATE posts SET title='$title', content='$content', cat_id='$category' WHERE id=$id" or die('your query has failed');
			$eq_r =mysql_query($eq);
		
		return $eq_r;
					
	}
	
	function add_category($name){
		$name = mysql_real_escape_string($name);
		 $query = "INSERT INTO categories SET name='$name' " or die('Query failed');
		 $query_run = mysql_query($query);
		return($query_run)?true:false;
	}
	
	function delete($table, $id){
		$table = mysql_real_escape_string($table);
		$id = (int)$id;
		
		$query = mysql_query("DELETE FROM $table WHERE id= $id");
		return $query;
	
	}
	
	function get_posts($id= null){
		$post = array();
		$p_q = "SELECT posts.id AS post_id, categories.id AS category_id, title,content,date_posted, categories.name FROM posts INNER JOIN categories ON categories.id = posts.cat_id ";
			if(isset($id)){
				$id = (int) $id;
				$p_q.="WHERE posts.id =".$id." ";
			}
				$p_q.="ORDER BY posts.id DESC ";
			
				$pq_r = mysql_query($p_q);
			
			while($rows= mysql_fetch_array($pq_r)){
			$post[] = $rows;
			
			}
		return $post;
	
	}
	
	function get_data($data){
		$list = array();
		
		$query = mysql_query("SELECT * FROM $data");
			
		while($row =mysql_fetch_array($query)){
			$list[] = $row;
			
		}
			return $list;
	}
	
	
	function get_notice($note){
		$not = array();
		
		$query = mysql_query("SELECT * FROM $note ORDER BY notie_id DESC LIMIT 1") or die('failed');;
			
		while($rows =mysql_fetch_array($query)){
			$not[] = $rows;
			
		}
			return $not;
	}
	
	function get_emp_notice($note){
		$not = array();
		
		$query = mysql_query("SELECT * FROM $note ORDER BY notie_id DESC LIMIT 10") or die('failed');;
			
		while($rows =mysql_fetch_array($query)){
			$not[] = $rows;
			
		}
			return $not;
	}
	
	function category_exist($field,$value){
		$field = mysql_real_escape_string($field);
		$value = mysql_real_escape_string($value);
		
		$query = mysql_query("SELECT COUNT(1) FROM categories WHERE $field = '$value'");
		
		return (mysql_result($query,0)==0)? false:true;
	}

?>