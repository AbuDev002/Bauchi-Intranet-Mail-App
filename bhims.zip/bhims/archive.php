<div class="mail-box">
                 <?php include_once('incs/mailbuttons.php');?>
                <div>
                  <aside class="lg-side">
                      <div class="inbox-body" style="border:1px solid silver;">
                        <br/>
                         <!--  <table class="table table-inbox table-hover table-responsive" id="archives">
                            <tbody>
                             
                          </tbody>
                          </table> -->
           <h5 style="margin-left: 10px;">Mails Archive</h5>
           <hr>
          <div class="row">
            <div class="col-md-3">
              <div class="list-group" style="margin-left: 10px;">
              
              <?php
                $id = $_SESSION['email'];
                include_once('connection.php');
                $query = "SELECT DATE_FORMAT( archivedate, '%M %Y' ) AS 'archive', DATE_FORMAT( archivedate, '%m' ) AS 'm', DATE_FORMAT( archivedate, '%Y' ) AS 'y', COUNT( archive_id ) AS 'total'
                FROM archives WHERE user_id='".$id."' GROUP BY DATE_FORMAT( archivedate, '%Y%M' ) ";
                      $getarchives = mysqli_query($conms,$query);
                      while($row = mysqli_fetch_assoc($getarchives)){
                        echo "<a data='m=".$row['m']."&y=".$row['y']."' class='list-group-item' href='javascript:void(0)'>".$row['archive']." (".$row['total'].")</a>";
                       
                      }
              ?>
              
              </div>
            </div>
            <div class="col-md-3">
              <div class='row well' id='titles'>
                <ul class="list-group"></ul>
              </div>
            </div>
            <div class="col-md-6">
                
                    <div class='' style='margin-left:20px;' id='article' >
                                  
                    </div>
                 
            </div>
          </div>

                    
                    

                      </div>
                  </aside>
              </div>
</div>