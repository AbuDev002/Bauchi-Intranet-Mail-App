<?php
session_start();
if(isset($_SESSION['email'])){
	header('location:HomePage.php');
}
$title ="Login Page";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>

	<div  class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				
		<center>
		
		<p><img src="images/logo.jpg" class="rounded-circle" width="100" height="100"></p>
		<div class="app-name" style="font-weight:normal !important"><i class="fa fa-envelope"></i> Bauchi State Intranet Mailing System</div>
		</center>

		<div  class="card" id="formContainer">
			<div class="card-body">
	            <p><div id="error"></div></p>
				<form id="admin-login" method="post">
					<center><h5><i class="fa fa-user"></i> Administrator's Only</h5></center>
					<a href="#" id="flipToLogin" class="flipLink"><i class="fa fa-right"></i></a>
					<br/>
					<br/>
					<div class="form-group">
						<input type="email" name="email" id="loginEmail" placeholder="Email address..." autocomplete="off" class="form-control">
					</div>

					<div class="form-group">
						<input type="password" name="password" id="recoverEmail" placeholder="Password..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<small id="emailHelp" class="form-text text-info" style="font-size:11px;text-align:right;"><i class="fa fa-question-circle"></i> <a href="#">Forgot your password? </a></small>
					</div>
					<div class="form-group">
						<button  name="submit" class="btn btn-primary btn-block login" id="admworking"> <i class="fa fa-sign-in"></i> Login </button>
					</div>	
				</form>
				
				
				<form  method="post" id="user-login">
					<center><h5 class="card-title"><i class="fa fa-users"></i> User's Login</h5></center>
					<a href="#" id="flipToRecover" class="flipLink"><i class="fa fa-arrow"></i></a>
					<br/>
					<br/>
					<div class="form-group">
						<input type="email" name="email" id="email" placeholder="Email address..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<input type="password" name="password" id="password" placeholder="Password..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<small id="emailHelp" class="form-text text-info" style="font-size:12px;text-align:right;"><i class="fa fa-question-circle"></i> <a href="#">Forgot your password? </a></small>
					</div>
					<div class="form-group">
						<button  class="btn btn-primary btn-block login" id="working"><i class="fa fa-sign-in"></i> Login </button>
					</div>	
				</form>
				</div>
		
			</div>

<div class="text-center" style="color:#222; font-size:10px;margin-top:10px;">Copyright &copy;
                                    <?php echo date('Y', time())?>
                                        Bauchi State of Nigeria - All right reserved.
                                            <br>Powered By <a href="http://www.gwanisoftware.com
" target="_blank" title="Developers" data-toggle="popover" data-trigger="hover" data-content="A product of Gwani Software" data-placement="bottom">Gwani Software</a></div>
                 
		</div>
		<div class="col-md-4"></div>
</div>
</div>
<?php include('incs/footer.php');?>