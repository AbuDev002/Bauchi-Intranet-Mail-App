<?php
session_start();
$email = $_SESSION['email'];	
$time = date("H:i:s");
include_once('connection.php');
mysqli_query($conms,"UPDATE logging_history SET time_out='".$time."' WHERE email='".$email."'");
	unset($_SESSION['email']);
	session_destroy();	
	header("location: index.php");
	// if() {
	// 	
	// }
?>