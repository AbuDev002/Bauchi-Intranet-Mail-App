<tbody>
<?php
session_start();
include_once('connection.php');
$id=$_SESSION['email'];
//$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($conms, $_POST["query"]);
	$query = "SELECT * FROM usermail WHERE sub LIKE '%".$search."%' OR msg LIKE '%".$search."%' AND rec_id='$id' ORDER BY mail_id DESC";
}
else
{
	$query="SELECT * FROM usermail WHERE rec_id='$id' ORDER BY mail_id DESC";
}
$result=mysqli_query($conms,$query);
if(mysqli_num_rows($result) >0){

while($row=mysqli_fetch_array($result)){
$mailcontent = substr($row['msg'],0,70);
$fextension = pathinfo($row['attachement'],PATHINFO_EXTENSION);
?>
<tr class="unread">
<td class="inbox-small-cells">
    <input type="checkbox" name='check[]' value='<?php echo $row['mail_id'];?>' class="mail-checkbox" id="mail-checkbox">
</td>
<td class="inbox-small-cells">
  <?php if($row['seenstatus'] == 1){?>
  <!-- <i class="fa fa-star"></i> -->
  <a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><i class="fa fa-envelope-open-o"><small> viewed</small></i></a>
<?php }else{?>
  <a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><span class="badge badge-secondary"><i class="fa fa-envelope"></i> New <small> Unread</small></span></a>

<?php } ?>
</td>
<td class="view-message  dont-show"><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><?php echo $row['sub'];?></a></td>
<td class="view-message "><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><?php echo $mailcontent.'...';?></a></td>
<td class="view-message  inbox-small-cells">
  <a href="<?php echo ($fextension=='pdf')?'makeidtofile.php?fid='.$row["mail_id"]:$row["attachement"];?>" target="_blank" title="Attachment"><?php if($row['attachement'] !==''){ echo '<i class="fa fa-paperclip"></i>';}?></a>
</td>
<td class="view-message  text-right"><small><?php echo $row['recDT'];?></small></td>
 <td class="view-message  text-right"><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>" title="Write Minutes"><i class="fa fa-edit"></i></a></td>
  <td class="view-message  text-right"><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>" title="View mail"><i class="fa fa-eye"></i></a></td>
   <td class="view-message  text-right"><a href="archivedmail.php?achmail=<?php echo $row['mail_id'];?>" title="Archive"><i class="fa fa-archive"></i></a></td>
</tr>
<?php }?>
<?php }else{ ?>
  <tr>
    <td align="center" colspan="10"><span>No message found in your mail box..</span></td>
  </tr>
<?php } ?>
</tbody>

