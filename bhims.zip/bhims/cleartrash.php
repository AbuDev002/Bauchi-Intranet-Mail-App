<?php
	include_once('connection.php');
	if(isset($_GET['rm'])){
		$delete = $_GET['rm'];
		$delete_query ="DELETE FROM trash WHERE trash_id ='".$delete."'";
		$query_run = mysqli_query($conms,$delete_query);
		if($query_run){
			header('location:HomePage.php?chk=trash');	
		}
	
	}

?>