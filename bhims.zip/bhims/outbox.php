<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>
			<div class="container">
				<?php include_once('incs/header.php')?>
				<div id="content">
					<table border="0" id="fimage" align="right" width="100%">
						<tr>
							<th colspan="3"><p id="msg" style='display:none;'>Collaborative Information System</p></th>
						</tr>
						<?php
							$did = $_SESSION['account_type'];
							$cquery = mysql_query("SELECT count(*) AS total FROM account WHERE message_to_dept_id='$did'");
							while($rows = mysql_fetch_array($cquery)){
								$total = $rows['total'];
							
							}
						?>
						
						<?php
							$didi = $_SESSION['account_type'];
							$cquery = mysql_query("SELECT count(*) AS total_out FROM account WHERE message_from_dept_id='$didi'");
							while($rows = mysql_fetch_array($cquery)){
								$out = $rows['total_out'];
							
							}
						?>
					</table>
						<table border="1"  align="left" width="30%">
						<tr>
							<td align="center"><a href="inbox.php"><button>Inbox(<?php echo $total;?>)</button></a></td>
						</tr>
						<tr>
							<td align="center"><a href="outbox.php"><button>Sent(<?php echo $out;?>)</button></a></td>
						</tr>
						<tr>
							<td align="center"><a href="logout.php"><button>Logout</button></a></td>
						</tr>
					</table>
					
					
					
					<table border="1"  align="right" width="70%">
						<tr>
							<td colspan="10" valign="top" height="400">
								<table border="1" align="center" width="100%">
									<tr>
										<td align="center"><a href="send_information.php"><button>Send Information</button></a></td>
										<td align="center"><a href="read_message.php"><button>Enter Meeting</button></a></td>
										<td align="center"><a href="staffs.php"><button>Employees</button></a></td>
										<td align="center"><a href="notice_board.php"><button>Notice Board</button></a></td>
										
									</tr>
								</table>
								
								<table border="1" align="center" width="100%">
								
									<tr>
										
										<th align="center">Message To</th>
										<th align="center">Sender Name</th>
										<th align="center">Message</th>
										<th align="center">Attachment</th>
										
									</tr>
									<?php
										$did = $_SESSION['account_type'];
										$cquery = mysql_query("SELECT * FROM account WHERE  message_from_dept_id='$did'");
										while($rows = mysql_fetch_array($cquery)){
											$msg_from = $rows['message_to_dept_id'];
											$msg_sender = $rows['sender_name'];
											$msg_content = $rows['message'];
											$msg_attachment = $rows['document'];
										
											switch($msg_from){
												case 1:
													$msg_from ="Director's Office";
													break;
												case 2:
													$msg_from ="Deputy Director's Office";
													break;
												case 3:
													$msg_from ="Chief Mobilization Office";
													break;
												case 4:
													$msg_from ="Servicom Office";
													break;	
												case 5:
													$msg_from ="ICPC Unit";
													break;
												case 6:
													$msg_from ="Public Relations Unit";
													break;	
												case 7:
													$msg_from ="Internal Audit Unit ";
													break;
												case 8:
													$msg_from ="Office of the Asst Director Programs";
													break;
												case 9:
													$msg_from ="Office of the Asst Director Operations";
													break;
												default:
													echo "Not in range";
													break;
											}
									?>
									<tr>
										
										<td align="center"><?php echo $msg_from;?></td>
										<td align="center"><?php echo $msg_sender;?></td>
										<td align="center"><?php echo $msg_content;?></td>
										<td align="center"><?php if($msg_attachment ==""){echo '<font color="red">No file attached</font>';}else{?> <a href="images/documents/<?php echo $msg_attachment.'"> Download</a>';}?></td>
										
									</tr>
									<hr/>
									<?php }?>
								</table>
								
								
							</td>
						</tr>
					</table>
					
					
					
				</div>
			</div>
<?php include_once('incs/footer.php');?>