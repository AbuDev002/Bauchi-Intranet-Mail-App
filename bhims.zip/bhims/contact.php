<?php
session_start();
if(!isset($_SESSION['username']) || !isset($_SESSION['email'])){
	header('location:index.php');
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>
			<div class="container">
				<?php include_once('incs/header.php')?>
				<div id="content">
					<table border="0" id="fimage" align="right" width="70%">
						<tr>
							<th colspan="3"><p id="msg" style='display:none;'>Organizational Chart</p></th>
						</tr>
						<tr>
							
							<td colspan="2" height='146' valign="top" align="center">Organizational</td>
						
						</tr>
						<tr>
							<td align="center" style="border:1px solid #000" colspan="2"><a href="index.php" onmousedown="bleep.Play()"><button>Home</button></a> &nbsp;|&nbsp;<a href="about.php" onmousedown="bleep.Play()"><button>About Us</button></a> &nbsp;|&nbsp;<a href="contact.php"><button>Chart</button></a> &nbsp;|&nbsp;<a href="exchange.php"><button>Contact Us</button></a></td>
							
						</tr>
						<tr>
							
							<td colspan="2" height="180" align="center"><img src="images/join.png"></td>
						</tr>
					</table>
					<?php include_once('incs/login.php');?>
					<?php include_once('incs/login_form.php');?>
				
				</div>
			</div>
			<table border="1" align="center" width="802">
				<tr>
					<td align="right">&copy; All right reserved NOA Bauchi</td>
				</tr>
			</table>
			
			<script type="text/javascript" src="js/jquery.js"></script>
			<script type="text/javascript" src="js/javascript.js"></script>
		</body>
</html>