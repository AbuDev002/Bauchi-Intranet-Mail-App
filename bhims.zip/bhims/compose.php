<?php
	include_once('connection.php');
	$id=$_SESSION['email'];
	$sentby=$_SESSION['account_type'];
	@$to=$_POST['to'];
	@$sub=$_POST['sub'];
	@$msg=$_POST['msg'];
	@$mailtype=$_POST['mailtype'];
	//@$file=$_FILES['file']['name'];,'pdf','doc','docx'
	@$permited  = array('jpg','jpeg','png','pdf');
	@$file_name = $_FILES['file']['name'];
	@$file_size = $_FILES['file']['size'];
	@$file_temp = $_FILES['file']['tmp_name'];
	@$div = explode('.', $file_name);
	@$file_ext = strtolower(end($div));
	@$unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
	@$uploaded_image ="uploads/offdocuments/".$unique_image;
	@$watermarkImagePath = 'images/stamp.png';

if(@$_REQUEST['send'])
{	
	
	if($to=="" || $sub=="" || $msg=="")
	{
	$err= "<p class='alert alert-danger'>Fill the related data first</p>";
	}else{
	if(!empty($file_name)){
		if ($file_size >1048567) {
				 echo "<p class='alert alert-danger'>Image Size should be less then 1MB!</p>";
			} elseif ($ext = in_array($file_ext, $permited) === false) {
				echo "<p class='alert alert-danger'>You can upload only:-".implode(', ', $permited)." files</p>";
			} else{
		$d=mysqli_query($conms,"SELECT * FROM userinfo WHERE email='$to'");
				$row=mysqli_num_rows($d);
				if($row==1){
					if(move_uploaded_file($file_temp, $uploaded_image)){
				
				// Load the stamp and the photo to apply the watermark to 
		if($file_ext =='jpg' || $file_ext =='jpeg' || $file_ext =='png'){
			    //@$watermarkImg = imagecreatefromjpeg($watermarkImagePath); 
			    @$watermarkImg = imagecreatefrompng($watermarkImagePath); 
		        switch($permited){ 
		            case 'jpg': 
		                $im = imagecreatefromjpeg($uploaded_image); 
		                break; 
		            case 'jpeg': 
		                $im = imagecreatefromjpeg($uploaded_image); 
		                break; 
		            case 'png': 
		                $im = imagecreatefrompng($uploaded_image); 
		                break;
		            default: 
		                 $im = imagecreatefromjpeg($uploaded_image); 
		        	} 
    // Set the margins for the watermark 
                $marge_right = 10; 
                $marge_bottom = 10; 
                 
                // Get the height/width of the watermark image 
                $sx = imagesx($watermarkImg); 
                $sy = imagesy($watermarkImg); 
                 
                // Copy the watermark image onto our photo using the margin offsets and  
                // the photo width to calculate the positioning of the watermark. 
                imagecopy($im, $watermarkImg, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($watermarkImg), imagesy($watermarkImg)); 
                 
                // Save image and free memory 
                imagepng($im, $uploaded_image); 
                imagedestroy($im);
                //after loading stamp if file type is image 
              }else{
              	//This page contains edit the existing file by using fpdi.
              	require_once('WatermarkPDF/WatermarkPDF.php');
              		//$pdfFile = $uploaded_image;
              		//@$pdfFile = $_FILES['file']['name'];
              		//@$file_temp = $_FILES['file']['tmp_name'];

					$watermarkText = "Bauchi State Government";
					$pdf = new WatermarkPDF($uploaded_image, $watermarkText);
					//$pdf = new FPDI();
					$pdf->AddPage();
					$pdf->SetFont('Arial', '', 12);


					/*$txt = "FPDF is a PHP class which allows to generate PDF files with pure PHP, that is to say " .
					        "without using the PDFlib library. F from FPDF stands for Free: you may use it for any " .
					        "kind of usage and modify it to suit your needs.\n\n";
					for ($i = 0; $i < 25; $i++) {
					    $pdf->MultiCell(0, 5, $txt, 0, 'J');
					}*/


					if($pdf->numPages>1) {
					    for($i=2;$i<=$pdf->numPages;$i++) {
					        //$pdf->endPage();
					        $pdf->_tplIdx = $pdf->importPage($i);
					        $pdf->AddPage();
					    }
					}

					$pdf->Output($uploaded_image,'F'); //If you Leave blank then it should take default "I" i.e. Browser
					//$pdf->Output("sampleUpdated.pdf", 'D'); //Download the file. open dialogue window in browser to save, not open with PDF browser viewer
					//$pdf->Output("save_to_directory_path.pdf", 'F'); //save to a local file with the name given by filename (may include a path)
					//$pdf->Output("sampleUpdated.pdf", 'I'); //I for "inline" to send the PDF to the browser
					//$pdf->Output("", 'S'); //return the document as a string. filename is ignored.
              }
				mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,attachement,sentby,mailtype,recDT) values('$to','$id','$sub','$msg','$uploaded_image','$sentby','$mailtype',sysdate())");
					$err= "<p class='alert alert-success'>Message sent...</p>";
				}

				}else{
					$sub=$sub."--"."msg failed";
					//move_uploaded_file($file_temp, $uploaded_image);
					mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,attachement,sentby,mailtype,recDT) values('$id','$id','$sub','$msg','$uploaded_image','$sentby','$mailtype',sysdate())");
					$err= "<p class='alert alert-danger'>Message failed...</p>";

			}
		}
	}else{
		mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,sentby,mailtype,recDT) values('$to','$id','$sub','$msg','$sentby','$mailtype',sysdate())");
					$err= "<p class='alert alert-success'>Message sent...</p>";
		}
		
		}
	}	


if(@$_REQUEST['save'])
{
	if($sub=="" || $msg=="")
	{
	$err= "<p class='alert alert-danger'>fill subject and msg first</font></p>";
	}
	
	else
	{
	$query="INSERT INTO draft values('','$id','$sub','$uploaded_image','$msg',sysdate())";
	mysqli_query($conms,$query);
	$err= "<p class='alert alert-success'>message saved to draft...</p>";
	}
}	
?>
		<?php if(isset($err)){ echo $err;}?>
		<form action="" method="post" enctype="multipart/form-data">
					 <table cellspacing="3" style="width:100%;padding:5px;">
		
					 	<tr>
					 		<td align="right" valign="top"><strong>To</strong>&nbsp;&nbsp;</td>
					 		<!-- mail type test -->
					 		<?php if($_SESSION['account_type'] =='Superadmin'){?>
					 			<td>	
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Superadmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo";
			                                // where account_type='Highleveladmin'
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Highleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Lowleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php } ?>
								</div>
					 		</td>
					 		<?php }else{?>
					 		<td>	
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Lowleveladmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Middleleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Highleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Superadmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php } ?>
								</div>
					 		</td>
					 		<?php } ?>
					 		
					 	</tr>
			
					 	<tr>
					 		<td align="right" valign="top"><strong>Subject</strong>&nbsp;&nbsp;</td>
					 		<td>
					 			<div class="form-group">
									<input type="text" name="sub" class="form-control" placeholder="Subject" autocomplete="off">
								</div>
					 		</td>
					 	</tr>
					 	<tr>
					 		<td align="right" valign="top"><strong>Attachment</strong>&nbsp;&nbsp;</td>
					 		<td>
					 			<div class="form-group">
									<div class="custom-file">
									  <input type="file" name="file" class="" id="customFile" style="height:30px;font-size: 12px;">
									</div>
								</div>
					 		</td>
					 	</tr>
					 	
					 </table>
					<div class="form-group">
						<textarea class="form-control ckeditor" cols="30" rows="4" name="msg"></textarea>
					</div>
					 <?php if($_SESSION['account_type'] == 'Superadmin'){?>
					 	<input type="hidden" name="mailtype" value="specialmail">
					 <?php }else{ ?>
					 	<input type="hidden" name="mailtype" value="normalmail">
					 <?php }?>
					<div class="form-group">
						<input type="submit" class="btn btn-default" value="Send"  name="send"  style="background: #DFE0DF;"> | 
						<input type="submit" name="save" value="Save as Draft" class="btn btn-default" style="background: #DFE0DF;">
					</div>
				</form>
				