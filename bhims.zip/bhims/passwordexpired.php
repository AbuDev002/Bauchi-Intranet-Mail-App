<?php
session_start();
if(!isset($_SESSION['passwordexpired'])){
	header('location:index.php');
}
$title ="Change Password";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>

	<div  class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				
		<center>
		
		<p><img src="images/logo.jpg" class="rounded-circle" width="100" height="100"></p>
		<div class="app-name" style="font-weight:normal !important"><i class="fa fa-envelope"></i> Intranet Mailing System</div>
		</center>
		<?php
	$error = "";
	if(isset($_POST['btnChngPass'])){
		//$current_password =strip_tags($_POST['current_password']);
		$new_password =strip_tags($_POST['new_password']);
		$repassword =strip_tags($_POST['repassword']);
		if($new_password && $repassword){
		if( $new_password == $repassword){
			//$pass_hash = md5($current_password);
				include_once('connection.php');
				$sec_hash = md5($new_password);
				$ses_id = $_SESSION['userid'];
					$query2 =mysqli_query($conms,"UPDATE userinfo SET password='".$sec_hash."' WHERE user_id =$ses_id");
					if($query2){
						$id=$_SESSION['email'];
						mysqli_query($conms,"UPDATE userinfo SET lastupdated=now() WHERE user_id='".$ses_id."'");
						header('location:HomePage.php');
					}
				}else
			$error ="<p class='alert alert-danger'>Your password do not match!</p>";
	}else
			$error ="<p class='alert alert-danger'>Please enter new password</p>";
	
	}
?>
		<?php if(isset($error)){ echo $error;}?>
		<div  class="card" id="formContainer">
			<div class="card-header">
				Your password has expired

			</div>
			<div class="card-body">
				
				<form  action="" method="post" id="change-password">
					
					<br/>
					<br/>
					<div class="form-group">
						<input type="password" name="new_password" id="npassword" placeholder="New Password..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<input type="password" name="repassword" id="npassword" placeholder="Confirm Password..." autocomplete="off" class="form-control">
					</div>
					<div class="form-group">
						<small id="emailHelp" class="form-text text-info" style="font-size:11px;text-align:right;"><i class="fa fa-info-circle"></i> <a href="#">Password need to be changed after 30 days </a></small>
					</div>
					<div class="form-group">
						<button  class="btn btn-primary btn-block" name="btnChngPass" id="working"><i class="fa fa-lock"></i> Change Password </button>
					</div>	
				</form>
				</div>
		
			</div>

<div class="text-center" style="color:#222; font-size:10px;margin-top:10px;">Copyright &copy;
                                    <?php echo date('Y', time())?>
                                        Bauchi State of Nigeria - All right reserved.
                                            <br>Powered By <a href="http://www.gwanisoftware.com
" target="_blank" title="Developers" data-toggle="popover" data-trigger="hover" data-content="A product of Gwani Software" data-placement="bottom">Gwani Software</a></div>
                 
		</div>
		<div class="col-md-4"></div>
</div>
</div>
<?php include('incs/footer.php');?>