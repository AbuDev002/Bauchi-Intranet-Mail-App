<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Manage Minutes";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
						<div class="row">
							<div class="col-md-4"></div>
							<div class="col-md-4">
								 <a href="add_minute.php" class="btn btn-default btn-block"><i class="fa fa-plus"></i> Add New Minute Quote</a>
					 <hr/>
					 <table class="table table-bordered table-responsive custom_table">
					 	<thead>
					 	<tr>
					 		<th>#</th>
					 		<th>Minute Quote</th>
					 		<th>Action</th>
					 	</tr>
					 	</thead>
					 	<tbody>
					 	<?php 
					 		$count = 0;
					 		if($_SESSION['account_type'] == 'Highleveladmin'){
					 			include_once('connection.php');
					 			$getminute_sql = mysqli_query($conms,"select * from minutes_quotes");
					 			while($rows_rs = mysqli_fetch_array($getminute_sql)){
					 			$count++;
							 	?>
							 	<tr>
							 		<td><?php echo $count;?></td>
							 		<td><?php echo $rows_rs['minute_text'];?></td>
							 		<td><a onclick="return confirm('Are you sure to delete');" href="deleteminute.php?deleteminute=<?php echo $rows_rs['id'];?>"><i class="fa fa-trash"></i></a></td>
							 	</tr>
							 <?php }} ?>
						 </tbody>
						 </table>
							</div>
							<div class="col-md-4"></div>
						</div>
					
						</div>
							
					</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>