<?php
	include_once('connection.php');
	$id=$_SESSION['email'];
	$sentby=$_SESSION['account_type'];
	if(!isset($_GET['cmpid']) || $_GET['cmpid'] == NULL ){
		echo "<script>window.location ='draft.php'</script>";
		//header("Location:catlist.php");
	}else{
		$cmpid = $_GET['cmpid'];
	}
?>
<?php
		if(@$_REQUEST['send']){
			$to = mysqli_real_escape_string($conms,$_POST['to']);
			$sub = mysqli_real_escape_string($conms,$_POST['sub']);
			$msg = mysqli_real_escape_string($conms,$_POST['msg']);
			$mailtype = mysqli_real_escape_string($conms,$_POST['mailtype']);
			$permited  = array('jpg', 'jpeg', 'png');
			$file_name = $_FILES['file']['name'];
			$file_size = $_FILES['file']['size'];
			$file_temp = $_FILES['file']['tmp_name'];

			$div = explode('.', $file_name);
			$file_ext = strtolower(end($div));
			$unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
			$uploaded_image ="uploads/offdocuments/".$unique_image;
			@$watermarkImagePath = 'images/watermarklogo.jpg';
			
			if($to =="" || $sub =="" || $msg ==""){
				echo "<p class='alert alert-danger'>Please enter all fields</p>";
			}else{
			if(!empty($file_name)){
				
			
			if ($file_size >1048567) {
			 echo "<p class='alert alert-danger'>Image Size should be less then 1MB!</p>";
			} elseif (in_array($file_ext, $permited) === false) {
				echo "<p class='alert alert-danger'>You can upload only:-".implode(', ', $permited)." files</p>";
			} else{
				$d=mysqli_query($conms,"SELECT * FROM userinfo WHERE email='$to'");
				$row=mysqli_num_rows($d);
				if($row==1){
					if(move_uploaded_file($file_temp, $uploaded_image)){
				// Load the stamp and the photo to apply the watermark to 
			    $watermarkImg = imagecreatefromjpeg($watermarkImagePath); 
		        switch($permited){ 
		            case 'jpg': 
		                $im = imagecreatefromjpeg($uploaded_image); 
		                break; 
		            case 'jpeg': 
		                $im = imagecreatefromjpeg($uploaded_image); 
		                break; 
		            case 'png': 
		                $im = imagecreatefrompng($uploaded_image); 
		                break;
		            default: 
		                 $im = imagecreatefromjpeg($uploaded_image); 
		        	} 
    // Set the margins for the watermark 
                $marge_right = 10; 
                $marge_bottom = 10; 
                 
                // Get the height/width of the watermark image 
                $sx = imagesx($watermarkImg); 
                $sy = imagesy($watermarkImg); 
                 
                // Copy the watermark image onto our photo using the margin offsets and  
                // the photo width to calculate the positioning of the watermark. 
                imagecopy($im, $watermarkImg, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($watermarkImg), imagesy($watermarkImg)); 
                 
                // Save image and free memory 
                imagepng($im, $uploaded_image); 
                imagedestroy($im); 
				$query = mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,attachement,sentby,mailtype,recDT) values('$to','$id','$sub','$msg','$uploaded_image','$sentby','$mailtype',sysdate())");
				if ($query) {
					$undraftmsg=mysqli_query($conms,"DELETE FROM draft WHERE draft_id=".$cmpid."");
					echo "<p class='alert alert-success'>Message sent.</p>";
				}else {
					echo "<p class='alert alert-danger'>Message not send!</p>";
				}
			}

		}
	 }
			}else{
				$query = mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,sentby,mailtype,recDT) values('$to','$id','$sub','$msg','$sentby','$mailtype',sysdate())");
				if ($query) {
					$undraftmsg=mysqli_query($conms,"DELETE FROM draft WHERE draft_id=".$cmpid."");
					echo "<p class='alert alert-success'>Message sent.</p>";
				}else {
					echo "<p class='alert alert-danger'>Message not send</p>";
			}	
		}
	 }
	}
?>

<?php
if(@$_REQUEST['save'])
{
	//$to = mysqli_real_escape_string($conms,$_POST['to']);
	$sub = mysqli_real_escape_string($conms,$_POST['sub']);
	$msg = mysqli_real_escape_string($conms,$_POST['msg']);
	if($sub=="" || $msg=="")
	{
	$err= "<p class='alert alert-danger'>fill subject and msg first</font></p>";
	}
	
	else
	{
	//$query="INSERT INTO draft values('','$id','$sub','$uploaded_image','$msg',sysdate())";
	$query="UPDATE draft SET user_id='$id', sub ='$sub', msg='$msg' WHERE draft_id=".$cmpid."";
	mysqli_query($conms,$query);
	$err= "<p class='alert alert-success'>message saved to draft...</p>";
	}
}		
?>
		<?php if(isset($err)){ echo $err;}?>
		<?php 
			$getmail_sql ="SELECT * FROM draft WHERE draft_id=".$cmpid."";
			$getmail_qry = mysqli_query($conms,$getmail_sql);
			while($getmail_rs = mysqli_fetch_array($getmail_qry)){
		?>
		<form action="" method="post" enctype="multipart/form-data">
					 <table cellspacing="3" style="width:100%;padding:5px;">
		
					 	<tr>
					 		<td align="right" valign="top"><strong>To</strong>&nbsp;&nbsp;</td>
					 		<!-- mail type test -->
					 		<?php if($_SESSION['account_type'] =='Superadmin'){?>
					 			<td>	
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Superadmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Highleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Highleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Lowleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php } ?>
								</div>
					 		</td>
					 		<?php }else{?>
					 		<td>	
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Lowleveladmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Middleleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Highleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Superadmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php } ?>
								</div>
					 		</td>
					 		<?php } ?>
					 		
					 	</tr>
			
					 	<tr>
					 		<td align="right" valign="top"><strong>Subject</strong>&nbsp;&nbsp;</td>
					 		<td>
					 			<div class="form-group">
									<input type="text" name="sub" value="<?php echo $getmail_rs['sub'];?>" class="form-control" placeholder="Subject" autocomplete="off">
								</div>
					 		</td>
					 	</tr>
					 	<tr>
					 		<td align="right" valign="top"><strong>Attachment</strong>&nbsp;&nbsp;</td>
					 		<td>
					 			<div class="form-group">
									<div class="custom-file">
									  <input type="file" name="file" class="" id="customFile" style="height:30px;font-size: 12px;">
									</div>
								</div>
					 		</td>
					 	</tr>
					 	
					 </table>
					<div class="form-group">
						<textarea class="form-control ckeditor" cols="30" rows="4" name="msg"><?php echo $getmail_rs['msg'];?></textarea>
					</div>
					 <?php if($_SESSION['account_type'] == 'Superadmin'){?>
					 	<input type="hidden" name="mailtype" value="specialmail">
					 <?php }else{ ?>
					 	<input type="hidden" name="mailtype" value="normalmail">
					 <?php }?>
					<div class="form-group">
						<input type="submit" class="btn btn-default" value="Send"  name="send"  style="background: #DFE0DF;"> | 
						<input type="submit" name="save" value="Save as Draft" class="btn btn-default" style="background: #DFE0DF;">
					</div>
				</form>
				<?php } ?>