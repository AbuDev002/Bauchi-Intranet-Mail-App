<?php
require_once('function.php');
connectdb();
session_start();

if(isset($_POST["email"]) or isset($_POST["password"])){

//sleep(1);


//$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];
$mdpass = md5($password);


$data = mysqli_fetch_array(mysqli_query($conms,"SELECT password,block,account_type,user_id,name,lastupdated FROM userinfo WHERE email='".$email."'"));
//$lastupdated = $data[5];
//$passwordexpiretime = date('Y-m-d',strtotime(date('Y-m-d',strtotime($lastupdated))." + 30 day"));
// elseif (date('Y-m-d') > $passwordexpiretime){
// 	//$_SESSION['userid'] = $data[3];
// 	echo "Your password has expired.";
// }
if ($data[1]==1) {
	echo "Your Account is Currently Blocked";
}elseif ($data[0] == $mdpass) {
//$return_arr["status"]=1;
//-------------------------------------------------->>>>>>>>>>>>>>>>>>>> Make Auth
//$tm = time();
//$si = "$email$tm";
//$sid = md5($si);
//$_SESSION['sid'] = $sid;
$_SESSION['account_type'] = $data[2];
$_SESSION['userid'] = $data[3];
$_SESSION['email'] = $email;
$_SESSION['name'] = $data[4];
$time = date("H:i:s");
$date = date("Y-m-d");
//$_SESSION['username'] = $email;
//mysqli_query($conms,"UPDATE userinfo SET sid='".$sid."' WHERE email='".$email."'");
$last_login =mysqli_query($conms,"UPDATE userinfo SET lastlogin=now() WHERE email ='".$email."'");
$login_session =mysqli_query($conms,"INSERT INTO logging_history (logindate,email,name,time_in,time_out) values('".$date."','".$email."','".$_SESSION['name']."','".$time."','Not Available')");
//-------------------------------------------------->>>>>>>>>>>>>>>>>>>> Make Auth
if($data[2] =="Highleveladmin"){
 	echo "Highleveladmin";
}elseif($data[2] =="Middleleveladmin"){
	echo "Middleleveladmin";
}elseif($data[2] =="Lowleveladmin"){
	echo "Lowleveladmin";
}elseif($data[2] =="Authenticator"){
	echo "Authenticator";
}elseif($data[2] =="Superadmin"){
	echo "Superadmin";
}else{
	echo "User does not exist";
}  //end else
exit();
}else{
	echo "Inavlid Username or Password";
}
}
?>