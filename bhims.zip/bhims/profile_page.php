  <?php
  session_start();
  if(!isset($_SESSION['email'])){
  	header('location:index.php');
  }
  $title ="Profile";
  ?>
  <?php include_once('incs/head.php');?>
  <?php include_once('incs/menu2.php');?>
  			<div class="container">
  				<?php include_once('incs/upnavbar.php');?>
  				<div class="row" style="background: #f5f5f5;">
  					<?php include_once('incs/sidemenu.php');?>
  					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
              <?php
                $userid = $_SESSION['userid'];
                include_once('connection.php');
                if($_SERVER['REQUEST_METHOD'] =='POST'){
                  $name = mysqli_real_escape_string($conms,$_POST['name']);
                  $email = mysqli_real_escape_string($conms,$_POST['email']);
                  $phoneno = mysqli_real_escape_string($conms,$_POST['phoneno']);
                  
                  $permited  = array('jpg', 'jpeg', 'png', 'gif');
                  $file_name = $_FILES['image']['name'];
                  $file_size = $_FILES['image']['size'];
                  $file_temp = $_FILES['image']['tmp_name'];

                  $div = explode('.', $file_name);
                  $file_ext = strtolower(end($div));
                  $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                  $uploaded_image = "uploads/passports/".$unique_image;
                  
                  if($name =="" || $email =="" || $phoneno ==""){
                    echo "<p class='alert alert-danger'>Please enter all fields</p>";
                  }else{
                  if(!empty($file_name)){

                  if ($file_size >1048567) {
                   echo "<p class='alert alert-danger'>Image Size should be less then 1MB!
                   </p>";
                  } elseif (in_array($file_ext, $permited) === false) {
                    echo "<p class='alert alert-danger'>You can upload only:-".implode(', ', $permited)."</p>";
                  } else{
                    move_uploaded_file($file_temp, $uploaded_image);
                    $query = "UPDATE userinfo 
                      SET 
                        name    ='".$name."',
                        email  ='".$email."',
                        mobile   ='".$phoneno."',
                        image  ='".$uploaded_image."'
                        WHERE user_id =".$userid."";
                    $updated_row = mysqli_query($conms,$query);
                  if ($updated_row) {
                    echo "<p class='alert alert-success'>Data Updated Successfully.
                   </p>";
                  }else {
                    echo "<p class='alert alert-danger'>Data Not Updated !</p>";
                  }
                 }
                }else{
                  $query = "UPDATE userinfo 
                      SET 
                        name    ='".$name."',
                        email  ='".$email."',
                        mobile   ='".$phoneno."'
                        WHERE user_id =".$userid."";
                    $updated_row = mysqli_query($conms,$query);
                  if ($updated_row) {
                    echo "<p class='alert alert-success'>Data Updated Successfully.
                   </p>";
                  }else {
                    echo "<p class='alert alert-danger'>Data Not Updated !</p>";
                } }
              }
              }
              ?>
              <?php
                $profiletid = $_SESSION['email']; 
                include_once('connection.php');
                $getprofile_sql ="SELECT * FROM userinfo WHERE email='".$profiletid."'";
                $getprofile_qry = mysqli_query($conms,$getprofile_sql);
                while($getprofile_rs = mysqli_fetch_array($getprofile_qry)){
              ?>
                 <form action="" method="post" enctype="multipart/form-data">
  					     <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                      <center><p>
                        <?php if($getprofile_rs['image'] !=""){?>
                          <img src="<?php echo $getprofile_rs['image'];?>" alt="Passport" class="rounded-circle" width="150" height="150">
                        <?php }else{?>
                           <img src="images/avarter.png" alt="Passport" class="rounded-circle">
                        <?php } ?>
                        </p></center>
                         <div class="form-group">
                        <input type="file" name="image">
                      </div>
                      <div class="form-group">
                      	<input type="text" name="name" class="form-control" value="<?php echo $getprofile_rs['name'];?>" placeholder="Name...">
                      </div>
                      <div class="form-group">
                      	<input type="text" disabled="disabled" class="form-control" value="<?php echo $getprofile_rs['email'];?>">
                         <input type="hidden" name="email" value="<?php echo $getprofile_rs['email'];?>">
                      </div>
                      <div class="form-group">
                      	<input type="text" name="phoneno" class="form-control" value="<?php echo $getprofile_rs['mobile'];?>" placeholder="Phone No...">
                      </div>
                      <div class="form-group">
                      	<button class="btn btn-primary btn-block margin-bottom">Update</button>
                      </div>
                    </div>
                    <div class="col-md-4">
                      
                    </div>
                 </div>
                 </form>
                 <?php }?>
  					 </div>
  				</div>
  			</form>
  			</div>
        
  <?php include_once('incs/footer.php');?>