<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="MailPage"
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>

				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
						 <?php if($_SESSION['account_type'] =='Authenticator'){?>
						   <a href="#" onclick="printDiv('mailContent');"><i class="fa fa-print"></i> Print</a>
						  <?php } ?>
					<hr/>
					 <?php 
					 	if(isset($_GET['vw'])){
					 		$vw = $_GET['vw'];
					 		$time = date("H:i:s");
							$date = date("Y-m-d");
					 		$mail_access_track =mysqli_query($conms,"INSERT INTO mails_access_history (email,name,dateofaccess,accesstime) values('".$_SESSION['email']."','".$_SESSION['name']."','".$date."','".$time."')");
					 		$updateseenstatus = mysqli_query($conms,"UPDATE usermail SET seenstatus = 1 WHERE mail_id= $vw");
					 	}
					 ?>
					 <?php
						if(isset($_POST['bntMinute'])){
							$id = $_SESSION['email'];
							$sentby = $_SESSION['account_type'];
							$minuteby = $_SESSION['name'];
							$minutestext = $_POST['minutestext'];
							//sending to details
							$to=$_POST['to'];
							$sub=$_POST['sub'];
							$msg=$_POST['msg'];
							$uploaded_image=$_POST['attachement'];
							$mailtype=$_POST['mailtype'];

							$minutestext = mysqli_real_escape_string($conms,$minutestext);
							if(empty($minutestext)){
								echo "<p class='alert alert-danger'>Please Write Minutes on for this mail</p>";
							}else{
								include_once('connection.php');
								$updatemail_sql="UPDATE usermail SET minute_quote='".$minutestext."', minuteby='".$minuteby."' WHERE mail_id=".$vw."";
								$updatemail_qry = mysqli_query($conms,$updatemail_sql);
								if($updatemail_qry){
									mysqli_query($conms,"INSERT INTO usermail (rec_id,sen_id,sub,msg,attachement,sentby,minute_quote,minuteby,mailtype,recDT) values('$to','$id','$sub','$msg','$uploaded_image','$sentby','$minutestext','$minuteby','$mailtype',sysdate())");
									echo "<p class='alert alert-success'>Minute Successful!</p>";
								}else{
									echo "<p class='alert alert-danger'>Unable to minute on this mail</p>";
								}
							}
						}
						?>

					 <?php 
					 		include_once('connection.php');
							$getmin_sql ="SELECT * FROM usermail WHERE mail_id=".$vw."";
							$getmin_qry = mysqli_query($conms,$getmin_sql);
							while($getmin_rs =mysqli_fetch_array($getmin_qry)){
						?>
					<div id="mailContent" class="mailContent">
					<p><strong>From: </strong> <?php echo $getmin_rs['sen_id'];?></p>
					<h3 style="font-size:16px;"><strong>RE:</strong> <?php echo $getmin_rs['sub'];?></h3>
					 <div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;" id="conDiv">
					 <p style="text-align:justify;line-height: 10px;"><?php echo $getmin_rs['msg'];?></p>
					</div>
					
					 <form action="" method="post">
					 	<?php if($_SESSION['account_type'] =='Superadmin'){?>
					 	<div class="form-group">
					 		<select class="form-control" name="minutestext" style="height:30px;font-size: 12px;">
					 			<option>--Select Minutes Quote--</option>
					 			<?php
									include_once('connection.php');
	                                $sql_getquote="SELECT * FROM minutes_quotes";
	                                $qrun=mysqli_query($conms,$sql_getquote);              
	                                while($row=mysqli_fetch_array($qrun)){
								?>
									<option value="<?php echo $row['minute_text']?>"><?php echo $row['minute_text'];?></option>
								<?php } ?>
					 		</select>
					 	</div>
						 <?php }else{?>
						 <div class="form-group">
					 		<textarea class="form-control" id="minutestext" name="minutestext" placeholder="Write Minutes..."></textarea>
					 	</div>
						 <?php }?>
					 	<div class="form-group" id="SendTo">
					 		<!-- mail type test -->
					 		<?php if($getmin_rs['mailtype'] =='specialmail'){?>
					 				
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Superadmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo";
			                                // where account_type='Highleveladmin'
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Highleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Middleleveladmin'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Lowleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{ ?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>

								<?php } ?>
								</div>
					 		
					 		<?php }else{?>
					 			
					 			<div class="form-group">
					 				<?php
										if($_SESSION['account_type'] =='Lowleveladmin'){
					 				?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Middleleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								 <?php  }else if($_SESSION['account_type'] =='Middleleveladmin'){?>
								 	<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Authenticator'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Highleveladmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }elseif($_SESSION['account_type'] =='Highleveladmin'){?>
									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo where account_type='Superadmin'";
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }else{ ?>

									<select name="to" class="form-control" style="height:30px;font-size: 12px;">
										<option>--Send To--</option>
										<?php
											include_once('connection.php');
			                                $sql_getreciever="SELECT * FROM userinfo";
			                                // where account_type='Highleveladmin'
			                                $qrun=mysqli_query($conms,$sql_getreciever);              
			                                while($row=mysqli_fetch_array($qrun)){
										?>
											<option value="<?php echo $row['email']?>"><?php echo $row['name'];?></option>
										<?php } ?>
									</select>
								<?php }?>
								</div>
					 		
					 		<?php } ?>
					 	</div>
					 	<div class="form-group">
					 		<input type="hidden" name="sub" value="<?php echo $getmin_rs['sub']?>">
					 		<input type="hidden" name="msg" value="<?php echo $getmin_rs['msg']?>">
					 		<input type="hidden" name="attachement" value="<?php echo $getmin_rs['attachement']?>">
					 	 <?php if($_SESSION['account_type'] == 'Superadmin'){?>
					 		<input type="hidden" name="mailtype" value="specialmail">
						 <?php }elseif($_SESSION['account_type'] == 'Lowleveladmin'){ ?>
						 	<input type="hidden" name="mailtype" value="normalmail">
						 <?php }else{?>
						 		<input type="hidden" name="mailtype" value="<?php echo $getmin_rs['mailtype']?>">
						 <?php } ?>
					 	</div>

					 	<div class="form-group" id="bntMinute">
					 		<button type="submit"  class="btn btn-primary" name="bntMinute"><i class="fa fa-reply"></i> Send Minutes</button>
					 	</div>
					 	
					 </form>
					<!--  <div id="mailContent" class="mailContent"> -->
					 <h4 style="font-size:16px;">Minutes</h4>

					 <div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;">
					 	<?php 
					 	if($getmin_rs['sentby'] =='Superadmin'){
					 		$color ='red';
					 	}elseif($getmin_rs['sentby'] =='Highleveladmin'){
					 		$color ='green';
					 	}else{
					 		$color ='black';
					 	}?>
					 <p style="color:<?php echo $color;?>"><strong>Minutes Quote:</strong><i class="fa fa-comment"></i> <?php echo $getmin_rs['minute_quote'];?></p>
					 <p style="color:<?php echo $color;?>"><strong>Minutes By:</strong> <?php echo $getmin_rs['minuteby'];?></p>
					 </div>
					 <?php } ?>
					  </div><!--End of mailcontent div-->
					 	<hr>
					 	<?php if($_SESSION['account_type'] =="Superadmin"){?>
					 		<h4 style="font-size:16px;">Previous Minutes</h4>
					 	<?php 
					 		include_once('connection.php');
					 		$getmin_sql ="SELECT * FROM usermail WHERE mail_id=".$vw."";
							$getmin_qry = mysqli_query($conms,$getmin_sql);
							$getmin_rs =mysqli_fetch_array($getmin_qry);

					 		 //$minsub = $getmin_rs['sub'];
							$getpmin_sql ="SELECT minute_quote,minuteby,sen_id,sentby,rec_id,recDT FROM usermail where sub='".$getmin_rs['sub']."'";
							$getpmin_qry = mysqli_query($conms,$getpmin_sql);
							while($getpmin_rs =mysqli_fetch_array($getpmin_qry)){
						?>
						<div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;" id="minDiv">
						<?php 
					 	if($getpmin_rs['sentby'] =='Superadmin'){
					 		$color ='red';
					 	}elseif($getpmin_rs['sentby'] =='Highleveladmin'){
					 		$color ='green';
					 	}else{
					 		$color ='black';
					 	}?>
						 <p style="color:<?php echo $color;?>"><strong>Minutes Quote:</strong><i class="fa fa-comment"></i> <?php echo $getpmin_rs['minute_quote'];?></p>
						 <p style="color:<?php echo $color;?>"><strong>Minutes By:</strong> <?php echo $getpmin_rs['minuteby'];?></p>
						 <p style="color:<?php echo $color;?>"><strong>Recieved From:</strong><i class="fa fa-share"></i> <?php echo $getpmin_rs['sen_id'];?></p>
						 
						 <p style="color:<?php echo $color;?>"><strong>Date Recieved:</strong> <?php echo $getpmin_rs['recDT'];?></p>
						 </div>
						 <?php } ?>
					 	<?php }?>
					 	<!--document authenticator admin get his exellency minutes an higlevel admin-->
					 	<?php if($_SESSION['account_type'] =="Authenticator"){?>
					 		<h4 style="font-size:16px;">Previous Minutes</h4>
					 	<?php 
					 		include_once('connection.php');
					 		$getmin_sql ="SELECT * FROM usermail WHERE mail_id=".$vw."";
							$getmin_qry = mysqli_query($conms,$getmin_sql);
							$getmin_rs =mysqli_fetch_array($getmin_qry);

					 		 //$minsub = $getmin_rs['sub'];
							$getpmin_sql ="SELECT minute_quote,minuteby,sen_id,sentby,rec_id,recDT FROM usermail WHERE sentby='Superadmin' || sentby='Highleveladmin' AND sub='".$getmin_rs['sub']."'";
							$getpmin_qry = mysqli_query($conms,$getpmin_sql);
							while($getpmin_rs =mysqli_fetch_array($getpmin_qry)){
								if($getpmin_rs['sentby'] =='Superadmin'){
					 				$color ='red';
							 	}elseif($getpmin_rs['sentby'] =='Highleveladmin'){
							 		$color ='green';
							 	}else{
							 		$color ='black';
							 	}
						?>
						<div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;color:<?php echo $color;?>" id="minDiv">
							
						 <p><strong>Minutes Quote:</strong><i class="fa fa-comment"></i> <?php echo $getpmin_rs['minute_quote'];?></p>
						 <p><strong>Minutes By:</strong> <?php echo $getpmin_rs['minuteby'];?></p>
						 <p><strong>Recieved From:</strong><i class="fa fa-share"></i> <?php echo $getpmin_rs['sen_id'];?></p>
						
						 <p><strong>Date Recieved:</strong> <?php echo $getpmin_rs['recDT'];?></p>
						 </div>
						 <?php } ?>
					 	<?php }?>


					 	<!--Middle level admin view minutes by his excellency -->
					 	<?php if($_SESSION['account_type'] =="Middleleveladmin"){?>
					 		<h4 style="font-size:16px;">Previous Minutes</h4>
					 	<?php 
					 		include_once('connection.php');
					 		$getmin_sql ="SELECT * FROM usermail WHERE mail_id=".$vw."";
							$getmin_qry = mysqli_query($conms,$getmin_sql);
							$getmin_rs =mysqli_fetch_array($getmin_qry);

					 		 //$minsub = $getmin_rs['sub'];
							$getpmin_sql ="SELECT minute_quote,minuteby,sen_id,sentby,rec_id,recDT FROM usermail WHERE sentby='Superadmin' AND sub='".$getmin_rs['sub']."'";
							$getpmin_qry = mysqli_query($conms,$getpmin_sql);
							while($getpmin_rs =mysqli_fetch_array($getpmin_qry)){
								if($getpmin_rs['sentby'] =='Superadmin'){
					 				$color ='red';
							 	}elseif($getpmin_rs['sentby'] =='Highleveladmin'){
							 		$color ='green';
							 	}else{
							 		$color ='black';
							 	}
						?>
						<div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;color:<?php echo $color;?>" id="minDiv">
							
						 <p><strong>Minutes Quote:</strong><i class="fa fa-comment"></i> <?php echo $getpmin_rs['minute_quote'];?></p>
						 <p><strong>Minutes By:</strong> <?php echo $getpmin_rs['minuteby'];?></p>
						 <p><strong>Recieved From:</strong><i class="fa fa-share"></i> <?php echo $getpmin_rs['sen_id'];?></p>
						
						 <p><strong>Date Recieved:</strong> <?php echo $getpmin_rs['recDT'];?></p>
						 </div>
						 <?php } ?>
					 	<?php }?>

					 	<!--Low level admin view minutes by his excellency -->
					 	<?php if($_SESSION['account_type'] =="Lowleveladmin"){?>
					 		<h4 style="font-size:16px;">Previous Minutes</h4>
					 	<?php 
					 		include_once('connection.php');
					 		$getmin_sql ="SELECT * FROM usermail WHERE mail_id=".$vw."";
							$getmin_qry = mysqli_query($conms,$getmin_sql);
							$getmin_rs =mysqli_fetch_array($getmin_qry);

					 		 //$minsub = $getmin_rs['sub'];
							$getpmin_sql ="SELECT minute_quote,minuteby,sen_id,sentby,rec_id,recDT FROM usermail WHERE sentby='Superadmin' AND sub='".$getmin_rs['sub']."'";
							$getpmin_qry = mysqli_query($conms,$getpmin_sql);
							while($getpmin_rs =mysqli_fetch_array($getpmin_qry)){
								if($getpmin_rs['sentby'] =='Superadmin'){
					 				$color ='red';
							 	}elseif($getpmin_rs['sentby'] =='Highleveladmin'){
							 		$color ='green';
							 	}else{
							 		$color ='black';
							 	}
						?>
						<div style="width:100%;border:1px solid silver;border-radius: 10px;padding:5px;margin: 5px;color:<?php echo $color;?>" id="minDiv">
							
						 <p><strong>Minutes Quote:</strong><i class="fa fa-comment"></i> <?php echo $getpmin_rs['minute_quote'];?></p>
						 <p><strong>Minutes By:</strong> <?php echo $getpmin_rs['minuteby'];?></p>
						 <p><strong>Recieved From:</strong><i class="fa fa-share"></i> <?php echo $getpmin_rs['sen_id'];?></p>
						
						 <p><strong>Date Recieved:</strong> <?php echo $getpmin_rs['recDT'];?></p>
						 </div>
						 <?php } ?>
					 	<?php }?>


					</div>
						
				</div>
		
			</div>
			
<?php include_once('incs/footer.php');?>
<script type="text/javascript">
	function printDiv(divName) {
	
		 var printContents = $("."+divName).html();// document.getElementById(divName).innerHTML;
		
		 var originalContents = document.body.innerHTML;
			//alert(printContents);
		
		 document.body.innerHTML = printContents;
		  document.getElementById("minutestext").style.display="none";
		  document.getElementById("bntMinute").style.display="none";
		  document.getElementById("SendTo").style.display="none";
		 window.print();

		 document.body.innerHTML = originalContents;
	}
</script>