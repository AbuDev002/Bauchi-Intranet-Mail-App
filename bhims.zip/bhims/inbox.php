<div class="mail-box">
                 <div class="row">
                  <div class="col-md-3">
                    <?php include_once('incs/mailbuttons.php');?>
                  </div>
                 <?php include_once('incs/mailsearch.php');?>
                </div>
                <div>
                  <aside class="lg-side">
                      <div class="inbox-body" style="border:1px solid silver;">
                        <br/>
                        <div class="table-responsive">
                          <table id="loadmails" class="table table-inbox table-hover">
                            
                          </table>
                        </div>
                      </div>
                  </aside>
              </div>
</div>
 </form><!--the open form tag is in the mailbuttons.php file-->