<?php
session_start();
include_once('connection.php');
$id=$_SESSION['email'];
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($conms, $_POST["query"]);
	$query = "
	SELECT * FROM usermail 
	WHERE sub LIKE '%".$search."%'
	OR msg LIKE '%".$search."%'
	";
}
else
{
	$query = "SELECT * FROM tbl_customer ORDER BY CustomerID";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["CustomerName"].'</td>
				<td>'.$row["Address"].'</td>
				<td>'.$row["City"].'</td>
				<td>'.$row["PostalCode"].'</td>
				<td>'.$row["Country"].'</td>
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>