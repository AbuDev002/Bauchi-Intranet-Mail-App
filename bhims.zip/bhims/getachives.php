<?php
    include_once('connection.php');
    extract($_REQUEST);
    $query = "select * from archives where YEAR(archivedate) = ".$y." AND MONTH(archivedate) = ".$m;
    $archives = mysqli_query($conms,$query);
    while($row = mysqli_fetch_assoc($archives)){
        echo "
			<li class='list-group-item list-group-item-action'><a class='archives' data='id=".$row['archive_id']."' href='javascript:void(0)'>".$row['sub']."</a></li>
		";
    }
?>