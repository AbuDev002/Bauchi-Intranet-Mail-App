<?php
session_start();
//error_reporting(1);
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Change Password";
?>
<?php
	$error = "";
	if(isset($_POST['chngP'])){
		$current_password =strip_tags($_POST['current_password']);
		$new_password =strip_tags($_POST['new_password']);
		$repassword =strip_tags($_POST['repassword']);
		if($current_password && $new_password && $repassword){
		if( $new_password == $repassword){
			$pass_hash = md5($current_password);
				include_once('connection.php');
				$query =mysqli_query($conms,"SELECT * FROM userinfo WHERE password='".$pass_hash."'");
					if(mysqli_num_rows($query)> 0){
						//include('connection/connect.php');
						$sec_hash = md5($new_password);
						$ses_id = $_SESSION['userid'];
						$id=$_SESSION['email'];
						//$lastupdated = time();
					$query2 =mysqli_query($conms,"UPDATE userinfo SET password='".$sec_hash."' WHERE user_id =$ses_id");
					if($query2){
						mysqli_query($conms,"UPDATE userinfo SET lastupdated=now() WHERE user_id='".$ses_id."'");
						$error ="<p class='alert alert-success'>Password Changed successfully!</p>";
					}
					}else{
						$error ="<p class='alert alert-danger'>Current Password Is Incorrect!</p>";
					}
				
		}else
			$error ="<p class='alert alert-danger'>Your password do not match!</p>";
	}else
			$error ="<p class='alert alert-danger'>Please enter your password</p>";
	
	}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					<form action="#" method="post">
						 <div class="card">
					 	<div class="card-header">Change Password</div>
					 	<div class="card-body">
					 		<?php if(isset($error)){ echo $error;}?>
					 		<div class="form-group">
					 			<input type="password" name="current_password" class="form-control" placeholder="Current Password...">
					 		</div>
					 		<div class="form-group">
					 			<input type="password" name="new_password" class="form-control" placeholder="New Password...">
					 		</div>
					 		<div class="form-group">
					 			<input type="password" name="repassword" class="form-control" placeholder="Confirm Password...">
					 		</div>
					 		
					 		<div class="form-group">
					 			<button type="submit" name="chngP" class="btn btn-primary margin-bottom"> Change Password </button>
					 		</div>
					 	
					 	</div>
					 </div>
						
					</form>
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>