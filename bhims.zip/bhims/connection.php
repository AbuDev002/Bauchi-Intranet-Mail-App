<?php
$conms = @mysqli_connect('localhost','root','','bhims');
?>