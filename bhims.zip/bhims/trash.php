<div class="mail-box">
               <?php include_once('incs/mailbuttons.php');?>
                <div>
                  <aside class="lg-side">
                      <div class="inbox-body" style="border:1px solid silver;">
                        <br/>
                          <table class="table table-inbox table-hover table-responsive">
                            <tbody>
                              <?php
                                include_once('connection.php');
                                $id=$_SESSION['email'];
                                $userid = $_SESSION['userid'];
                                $sql="SELECT * FROM trash WHERE rec_id='$id'";
                                $dd=mysqli_query($conms,$sql);
                                if(mysqli_num_rows($dd) >0){
                                while($row=mysqli_fetch_array($dd)){
                                	$mailcontent = substr($row['msg'],0,70)
                              ?>
                              <tr class="unread">
                                 
                                  <td class="inbox-small-cells"><i class="fa fa-envelope-open-o"></i></td>
                                  <td class="view-message  dont-show"><?php echo $row['sub'];?></td>
                                  <td class="view-message "><?php echo $mailcontent.'...';?></td>
                                  <td class="view-message  inbox-small-cells"><i class="fa fa-paperclip"></i></td>
                                  <td class="view-message  text-right"><?php echo $row['date'];?></td>
                                   <td class="inbox-small-cells">
            
                                      <a href="cleartrash.php?rm=<?php echo $row['trash_id'];?>"><i class="fa fa-trash" onclick="return confirm('Are you sure to permanent delete?');"></i></a>
                                  </td>
                              </tr>
                             <?php }}else{ echo "<center><p class='alert alert-info'>No message in trash..</p></center>";} ?>
                             
                          </tbody>
                          </table>
                      </div>
                  </aside>
              </div>
</div>