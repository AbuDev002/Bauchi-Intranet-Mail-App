<?php
include_once('connection.php');
if(isset($_GET['bid'])) {
$bid = $_GET['bid']; 
$act = $_GET['act']; 
$userDetails = mysqli_query($conms,"UPDATE userinfo SET block=".$act." WHERE user_id=".$bid."");
header('location:users.php');
}else{
    header('location:users.php');
}
?>