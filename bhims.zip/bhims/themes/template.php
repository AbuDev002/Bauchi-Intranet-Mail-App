<?php
session_start();
//error_reporting(0);
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
	<div  class="container">
		<?php include_once('incs/upnavbar.php');?>
		<div class="row" style="background: #f5f5f5;">
			<?php include_once('incs/sidemenu.php');?>
			 <div class="col-sm-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
			 		<?php require_once $content;?>
			</div>
		
</div>
<?php include_once('incs/copyright.php');?>
<?php include('incs/footer.php');?>

<script>
  $(document).ready(function(){
    $(".list-group-item").click(function(){
        data = $(this).attr('data');
        titles = data.split("&");
        eval(titles[0]);
        eval(titles[1]);
        
        
        if(m==="" || y===""){
            return
        }
        $.ajax({
            type: "POST",
            url: "./getachives.php",
            data: {m:m,y:y},
            dataType: "text",
            success: function(resultData){
         
            $('#titles').html(resultData);

            }//end success

      }); //end ajax
       
    }); //end event
      
    $(document).on('click', '.archives', function(){
        
        data = $(this).attr('data');
        eval(data);
        
        if(id===""){
            return
        }
        $.ajax({
            type: "POST",
            url: "./getachivescontent.php",
            data: {id:id},
            dataType: "text",
            success: function(resultData){
         
            $('#article').html(resultData);

            }//end success

      }); //end ajax
       
    }); //end event  
   
      
  }); //end script
</script>