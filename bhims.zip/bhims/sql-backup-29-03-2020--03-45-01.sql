-- Database: `bhims` --
-- Table `archives` --
CREATE TABLE `archives` (
  `archive_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `attach` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `archivedate` date NOT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `draft` --
CREATE TABLE `draft` (
  `draft_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `attach` varchar(200) NOT NULL,
  `msg` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`draft_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `logging_history` --
CREATE TABLE `logging_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logindate` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `time_in` varchar(100) NOT NULL,
  `time_out` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `logging_history` (`id`, `logindate`, `email`, `name`, `time_in`, `time_out`) VALUES
(1, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '09:49:37', '13:23:40'),
(2, '2020-03-29', 'staff1@bh.gov.ng', 'Staff 1', '09:50:12', '09:52:12'),
(3, '2020-03-29', 'comissioner1@bh.gov.ng', 'Comissioner of FInance', '09:52:27', '11:31:47'),
(4, '2020-03-29', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '09:54:03', '13:34:45'),
(5, '2020-03-29', 'pps@bh.gov.ng', 'PPS', '09:55:04', '13:24:44'),
(6, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '09:56:05', '13:23:40'),
(7, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '10:11:38', '13:23:40'),
(8, '2020-03-29', 'pps@bh.gov.ng', 'PPS', '10:46:29', '13:24:44'),
(9, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '10:47:18', '13:23:40'),
(10, '2020-03-29', 'pps@bh.gov.ng', 'PPS', '11:30:27', '13:24:44'),
(11, '2020-03-29', 'comissioner1@bh.gov.ng', 'Comissioner of FInance', '11:31:26', '11:31:47'),
(12, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '11:32:45', '13:23:40'),
(13, '2020-03-29', 'pps@bh.gov.ng', 'PPS', '11:51:08', '13:24:44'),
(14, '2020-03-29', 'superadmin@bh.gov.ng', 'His Excellency', '13:22:08', '13:23:40'),
(15, '2020-03-29', 'pps@bh.gov.ng', 'PPS', '13:23:52', '13:24:44'),
(16, '2020-03-29', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '13:25:04', '13:34:45'),
(17, '2020-03-29', 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '13:37:20', 'Not Available');

-- Table `mails` --
CREATE TABLE `mails` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(50) NOT NULL,
  `sen_id` varchar(50) NOT NULL,
  `sub` char(50) NOT NULL,
  `msg` text NOT NULL,
  `draft` text NOT NULL,
  `trash` text NOT NULL,
  `attachement` varchar(200) NOT NULL,
  `msgdate` varchar(50) NOT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `mails_access_history` --
CREATE TABLE `mails_access_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dateofaccess` varchar(100) NOT NULL,
  `accesstime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

INSERT INTO `mails_access_history` (`id`, `email`, `name`, `dateofaccess`, `accesstime`) VALUES
(1, 'comissioner1@bh.gov.ng', 'Comissioner of FInance', '2020-03-29', '09:52:37'),
(2, 'comissioner1@bh.gov.ng', 'Comissioner of FInance', '2020-03-29', '09:53:26'),
(3, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '09:54:22'),
(4, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '09:54:46'),
(5, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '09:55:13'),
(6, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '09:55:42'),
(7, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '09:56:15'),
(8, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '09:57:04'),
(9, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:00:22'),
(10, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:08:23'),
(11, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:09:03'),
(12, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:11:07'),
(13, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:11:46'),
(14, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:12:33'),
(15, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:13:45'),
(16, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:15:21'),
(17, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:17:39'),
(18, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:39:02'),
(19, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:40:19'),
(20, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:42:40'),
(21, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '10:46:48'),
(22, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:47:26'),
(23, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:48:22'),
(24, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:50:12'),
(25, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:53:42'),
(26, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:53:53'),
(27, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:54:42'),
(28, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:56:22'),
(29, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:57:49'),
(30, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '10:58:08'),
(31, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:00:32'),
(32, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:01:16'),
(33, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:03:12'),
(34, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:03:44'),
(35, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:04:25'),
(36, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:04:44'),
(37, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:05:29'),
(38, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:07:36'),
(39, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:09:41'),
(40, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:10:32'),
(41, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:12:57'),
(42, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:15:57'),
(43, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:16:23'),
(44, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:17:29'),
(45, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:17:43'),
(46, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:19:20'),
(47, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:20:11'),
(48, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:21:58'),
(49, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:22:20'),
(50, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:22:47'),
(51, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:23:10'),
(52, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:23:51'),
(53, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:25:31'),
(54, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:30:08'),
(55, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '11:30:34'),
(56, 'comissioner1@bh.gov.ng', 'Comissioner of FInance', '2020-03-29', '11:31:41'),
(57, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:32:58'),
(58, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:44:06'),
(59, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:47:17'),
(60, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '11:49:08'),
(61, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '11:58:15'),
(62, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '11:59:59'),
(63, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '12:00:52'),
(64, 'superadmin@bh.gov.ng', 'His Excellency', '2020-03-29', '13:22:22'),
(65, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '13:24:16'),
(66, 'pps@bh.gov.ng', 'PPS', '2020-03-29', '13:24:39'),
(67, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:25:31'),
(68, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:39:18'),
(69, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:42:14'),
(70, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:42:49'),
(71, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:42:53'),
(72, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:43:26'),
(73, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:43:54'),
(74, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '13:44:42'),
(75, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '14:40:21'),
(76, 'docauthenticator@bh.gov.ng', 'Document Verification Officer', '2020-03-29', '15:00:00');

-- Table `minutes_quotes` --
CREATE TABLE `minutes_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minute_text` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `minutes_quotes` (`id`, `minute_text`) VALUES
(1, 'KIV'),
(2, 'Discuss'),
(3, 'Approve'),
(4, 'Refer'),
(5, 'ODE'),
(6, 'BU');

-- Table `trash` --
CREATE TABLE `trash` (
  `trash_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(50) NOT NULL,
  `sen_id` varchar(50) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `msg` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`trash_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `userinfo` --
CREATE TABLE `userinfo` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `account_type` varchar(100) NOT NULL,
  `block` int(11) NOT NULL DEFAULT '0',
  `sid` varchar(100) NOT NULL,
  `lastlogin` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`username`,`mobile`,`email`),
  KEY `gender` (`gender`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `userinfo` (`user_id`, `name`, `username`, `password`, `mobile`, `email`, `gender`, `image`, `account_type`, `block`, `sid`, `lastlogin`) VALUES
(1, 'His Excellency', 'Superadmin', '5f4dcc3b5aa765d61d8327deb882cf99', '--', 'superadmin@bh.gov.ng', '--', '', 'Superadmin', 0, 'd896bd07e87dd9b567c23d92b581c40a', '2020-03-29 12:22:08'),
(2, 'Chief of Staff', 'Chief of Staff', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'chiefofstaff@bh.gov.ng', 'Male', '', 'Highleveladmin', 0, 'b027d8a2c3c2ec9396a58d437bf774e7', '2020-03-23 13:16:31'),
(3, 'PPS', 'PPS', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'pps@bh.gov.ng', 'Male', '', 'Highleveladmin', 0, '838fbeb79ed2e319399f07ee9045d902', '2020-03-29 12:23:52'),
(4, 'Document Verification Officer', 'Document Verification Officer', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'docauthenticator@bh.gov.ng', 'Male', '', 'Authenticator', 0, 'fdf58c8827962afb5ce22855fdebc7e8', '2020-03-29 12:37:20'),
(5, 'Comissioner of FInance', 'Comissioner of FInance', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'comissioner1@bh.gov.ng', 'Male', '', 'Middleleveladmin', 0, '7c0855b79007e4cbce16717c62402690', '2020-03-29 10:31:26'),
(6, 'Staff 1', 'staff1', '5f4dcc3b5aa765d61d8327deb882cf99', '', 'staff1@bh.gov.ng', 'Male', '', 'Lowleveladmin', 0, '62c0c25536c346963bd6ae1a67abeea8', '2020-03-29 08:50:12');

-- Table `usermail` --
CREATE TABLE `usermail` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_id` varchar(30) NOT NULL,
  `sen_id` varchar(30) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `attachement` text NOT NULL,
  `minute_quote` varchar(100) NOT NULL,
  `minuteby` varchar(100) NOT NULL,
  `mailtype` varchar(100) NOT NULL,
  `recDT` date NOT NULL,
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

