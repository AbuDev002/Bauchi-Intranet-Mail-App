<?php
include_once('connection.php');
if(isset($_GET['deleteminute'])) {
$deltid = $_GET['deleteminute']; 
$deletemin = mysqli_query($conms,"DELETE FROM minutes_quotes WHERE id=".$deltid."");
header('location:manage_minutes.php');
}else{
    header('location:manage_minutes.php');
}
?>