<?php
	if(isset($_GET['achmail'])){
		$achmail = $_GET['achmail'];
		include_once('connection.php');
		$getmail = mysqli_query($conms,"select * from usermail where mail_id = ".$achmail."");
		$mail_details = mysqli_fetch_array($getmail);
		$mail_id = $mail_details['mail_id'];
		$rec_id = $mail_details['rec_id'];
		$sen_id = $mail_details['sen_id'];
		$sub = $mail_details['sub'];
		$msg = $mail_details['msg'];
		$attachement = $mail_details['attachement'];
		$recDT = $mail_details['recDT'];
		$movetoachive = mysqli_query($conms,"insert into archives (user_id,sub,attach,msg,archivedate) value('".$rec_id."','".$sub."','".$attachement."','".$msg."','".$recDT."')");
		if($movetoachive){
			$removefrommailbox = mysqli_query($conms,"delete from usermail where mail_id =".$mail_id."");
			echo "<script> alert('Archived Successfully')</script>";
			//echo "<script> window.open('_self','HomePage.php')</script>";
			header("location:HomePage.php");
		}
	}else{
		header("location:HomePage.php");
	}

?>