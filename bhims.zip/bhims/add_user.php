<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					<?php
					
					if(isset($_POST['btnAddUser'])){
					$name = $_POST['name'];
					$username = $_POST['username'];
					$password = md5($_POST['password']);
					$phoneno = $_POST['phoneno'];
					$email = $_POST['email'];
					$gender = $_POST['gender'];
					$account_type = $_POST['account_type'];
					
					
					$name = mysqli_real_escape_string($conms,$name);
					$username = mysqli_real_escape_string($conms,$username);
					$password = mysqli_real_escape_string($conms,$password);
					$phoneno = mysqli_real_escape_string($conms,$phoneno);
					$email = mysqli_real_escape_string($conms,$email);
					$gender = mysqli_real_escape_string($conms,$gender);
					$account_type = mysqli_real_escape_string($conms,$account_type);
					
					if(empty($name) || empty($username) || empty($password) || empty($account_type) || empty($email)){
						echo "<p class='alert alert-danger'>All fields are required</p>";
					}else{
						include_once('connection.php');
						//$checkmail_sql =;
						$checkmail_qry = mysqli_query($conms,"SELECT * FROM userinfo WHERE email='".$email."' LIMIT 1");
						if(mysqli_num_rows($checkmail_qry) == 1){
							echo "<p class='alert alert-danger'>Email already exist</p>";
					}else{
						include_once('connection.php');
						//$adduser_sql =;
						$adduser_qry = mysqli_query($conms,"INSERT INTO userinfo (name,username,password,mobile,email,gender,account_type)  VALUES('".$name."','".$username."','".$password."','".$phoneno."','".$email."','".$gender."','".$account_type."')");
						if($adduser_qry){
							echo "<p class='alert alert-success'>User Created Successfully!</p>";
						}else{
							echo "<p class='alert alert-danger'>Unable to create user</p>";
						}
					}
				}
			}
			?>
					<form action="" method="post">
						 <div class="card">
					 	<div class="card-header"><span class="fa fa-plus"></span> Add New User</div>
					 	<div class="card-body">
					 		<div class="form-group">
					 			<input type="text" name="name" class="form-control" placeholder="Full Name...">
					 		</div>
					 		<div class="form-group">
					 			<input type="text" name="username" class="form-control" placeholder="Username...">
					 		</div>
					 		<div class="form-group">
					 			<input type="password" name="password" class="form-control" placeholder="Password...">
					 		</div>
					 		<div class="form-group">
					 			<input type="text" name="phoneno" class="form-control" placeholder="Phone No...">
					 		</div>
					 		
					 		<div class="form-group">
					 			<input type="text" name="email" class="form-control" placeholder="Email...">
					 		</div>
					 		
					 		<div class="form-group">
					 			<select class="form-control" name="gender">
					 					<option>--Select Gender--</option>
					 					<option value="Male">Male</option>
					 					<option value="Female">Female</option>
					 			</select>
					 		</div>
					 		<div class="form-group">
					 			<select class="form-control" name="account_type">
				 				<option>--Account Type--</option>
				 				<?php if($_SESSION['account_type'] =='Superadmin'){?>
				 				<option value="Highleveladmin">High Level Admin</option>
				 				<?php }elseif($_SESSION['account_type'] =='Highleveladmin'){?>
				 					<option value="Authenticator">Document Authenticator</option>
				 				<?php }elseif($_SESSION['account_type'] =='Authenticator'){?>
				 					<option value="Middleleveladmin">Middle Level Admin</option>
				 				<?php }elseif($_SESSION['account_type'] =='Middleleveladmin'){ ?>
				 					<option value="Lowleveladmin">Low Level Admin</option>
				 				<?php }else{?>
				 					<option value="Middleleveladmin">Middle Level Admin</option>
				 				<?php }?>
					 			</select>
					 		</div>
					 		<div class="form-group">
					 			<button type="submit" class="btn btn-primary margin-bottom" name="btnAddUser"><i class="fa fa-plus"></i> Add User</button>
					 		</div>
					
					 	</div>
					 </div>
						
					</form>
				</div>
			</div>
			
<?php include_once('incs/footer.php');?>