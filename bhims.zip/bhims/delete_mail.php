<?php
include_once('connection.php');
$rowCount = count($_POST["check"]);
for($i=0;$i<$rowCount;$i++) {
$getmail = mysqli_query($conms,"select * from usermail where mail_id=".$_POST["check"][$i]."");
$rs = mysqli_fetch_array($getmail);
 $move_to_trash = mysqli_query($conms,"INSERT INTO trash (rec_id,sen_id,sub,msg) VALUES('".$rs['rec_id']."','".$rs['sen_id']."','".$rs['sub']."','".$rs['msg']."')");
$query = "DELETE FROM usermail WHERE mail_id=".$_POST["check"][$i]."";
	$qr = mysqli_query($conms,$query);
}
header("Location:HomePage.php");
?>