<div class="container">
			<?php
				@$id=$_SESSION['userid'];
				$content='default_content.php';
				$chk = (isset($_REQUEST['chk']) && $_REQUEST['chk'] != '') ? $_REQUEST['chk'] : '';
				switch ($chk) {
					case 'vprofile' :
				        $title="Profile Page";	
						$content='profile_page.php';		
						break;
					case 'compose' :
					    $title="Compose Mail";	
						$content ='compose.php';
						break;
					case 'sent' :
					    $title="Sent Mail";	
						$content ='sent.php';
						break;
					case 'trash' :
					    $title="Trash";	
						$content ='trash.php';
						break;
					case 'inbox' :
					    $title="Inbox";	
						$content = 'inbox.php';		
						break;
					case 'draft' :
					    $title="Draft";	
				 		$content ='draft.php';		
						break;
					case 'archive' :
					    $title="Archive";	
				 		$content ='archive.php';		
						break;
					case 'recompose' :
					    $title="Recompose Message";	
				 		$content ='Recompose.php';		
						break;
					default :
					    $title="Home";	
						$content ='default_content.php';		
				}
			?>
					
					<!--inbox -->
					<?php
					@$id=$_SESSION['email'];
					@$coninb=$_GET['coninb'];
						
						if($coninb)
						{
						include_once('connection.php');
						$sql="SELECT * FROM usermail where rec_id='$id' and mail_id='$coninb' ORDER BY mail_id DESC";
				$dd=mysqli_query($conms,$sql);
						$row=mysqli_fetch_object($dd);
						echo "Subject :".$row->sub."<br/>";
						echo "Message :".$row->msg;
						}
						
						
				@$cheklist=$_REQUEST['ch'];
				if(isset($_GET['delete']))
				{
					foreach($cheklist as $v)
					{
					
					$d="DELETE from usermail where mail_id='$v'";
					mysqli_query($conms,$d);
					}
					echo "msg deleted";
				}
						
					?>
				
				<!--sent box-->
				<?php
					@$id=$_SESSION['email'];
					@$consent=$_GET['consent'];
						
						if($consent)
						{
						$sql="SELECT * FROM usermail where sen_id='$id' and mail_id='$consent' ORDER BY mail_id DESC";
			$dd=mysqli_query($conms,$sql);
						$row=mysqli_fetch_object($dd);
						echo "Subject :".$row->sub."<br/>";
						echo "Message :".$row->msg;
						}
						
						
				@$cheklist=$_REQUEST['ch'];
				if(isset($_GET['delete']))
				{
					foreach($cheklist as $v)
					{
					$d="DELETE from usermail where mail_id='$v'";
					mysqli_query($conms,$d);
					}
					echo "msg deleted";
				}
						
					?>	
    		</div>
<?php require_once 'themes/template.php';?>