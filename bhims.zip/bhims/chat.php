<?php
session_start();
if(!isset($_SESSION['username']) || !isset($_SESSION['email'])){
	header('location:index.php');
}

function get_data($data){
	include_once('connection.php');
	$list = array();
	
	$query = mysqli_query($conms,"SELECT * FROM $data");
		
	while($row =mysqli_fetch_array($query)){
		$list[] = $row;
		
	}
		return $list;
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="send_information.php" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu_adminhigh.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
						 <div class="card">
					 	<div class="card-header">Chatting</div>
					 	<div class="card-body">
					 		<div id="chatContainer">

							<div id="chatTopBar" class="rounded"></div>
								<div id="chatLineHolder"></div>

									<div id="chatUsers" class="rounded"></div>
										<div id="chatBottomBar" class="rounded">
							<div class="tip"></div>

							<form id="loginForm" method="post" action="">
								<input id="name" name="name" class="rounded" maxlength="16" />
								<input id="email" name="email" class="rounded" />
								<input type="submit" class="blueButton" value="Start" />
							</form>

						<form id="submitForm" method="post" action="">
							<input id="chatText" name="chatText" class="rounded" maxlength="255" />
							<input type="submit" class="blueButton" value="Send" />
						</form>

							</div>
						</div>
					 		
					 	</div>
					 </div>
					
				</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>