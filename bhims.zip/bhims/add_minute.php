<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					<?php
					
					if(isset($_POST['btnAddMinute'])){
					$minute_quote = $_POST['minute_quote'];

					$minute_quote = mysqli_real_escape_string($conms,$minute_quote);
					
					if(empty($minute_quote)){
						echo "<p class='alert alert-danger'>Please enter minute quote</p>";
					}else{
						include_once('connection.php');
						$checkminute_qry = mysqli_query($conms,"SELECT * FROM minutes_quotes WHERE minute_text='".$minute_quote."' LIMIT 1");
						if(mysqli_num_rows($checkminute_qry) == 1){
							echo "<p class='alert alert-danger'>Minute already exist</p>";
					}else{
						include_once('connection.php');
						$addminute_qry = mysqli_query($conms,"INSERT INTO minutes_quotes (minute_text)  VALUES('".$minute_quote."')");
						if($addminute_qry){
							echo "<p class='alert alert-success'>Minute Created Successfully!</p>";
						}else{
							echo "<p class='alert alert-danger'>Unable to create minute</p>";
						}
					}
				}
			}
			?>
					<form action="" method="post">
						 <div class="card">
					 	<div class="card-header"><span class="fa fa-plus"></span> Create Minute Quote</div>
					 	<div class="card-body">
					 		
					 		
					 		<div class="form-group">
					 			<input type="text" name="minute_quote" class="form-control" placeholder="Enter minute quote...">
					 		</div>
					 		<div class="form-group">
					 			<button type="submit" class="btn btn-primary margin-bottom" name="btnAddMinute"><i class="fa fa-plus"></i> Create Minute</button>
					 		</div>
					
					 	</div>
					 </div>
						
					</form>
				</div>
			</div>
			
<?php include_once('incs/footer.php');?>