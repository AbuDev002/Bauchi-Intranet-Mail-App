 <?php
 session_start();
include_once('connection.php');
@$id=$_SESSION['email'];
$sql_getinbox="SELECT count(*) as totalinbox FROM usermail where sen_id='$id'";
$totalinbox=mysqli_query($conms,$sql_getinbox);
$row = mysqli_fetch_array($totalinbox);
echo $row['totalinbox'];
?>