<div class="mail-box">
                 <?php include_once('incs/mailbuttons.php');?>
                <div>
                  <aside class="lg-side">
                      <div class="inbox-body" style="border:1px solid silver;">
                        <br/>
                        <div class="table-responsive">
                          <table class="table table-inbox table-hover">
                            <tbody>
                              <?php
                                include_once('connection.php');
                                $id=$_SESSION['email'];
                                $userid = $_SESSION['userid'];
                                $sql="SELECT * FROM draft WHERE user_id='$id'";
                                $dd=mysqli_query($conms,$sql);
                                if(mysqli_num_rows($dd) >0){
                                while($row=mysqli_fetch_array($dd)){
                                	$mailcontent = substr($row['msg'],0,70)
                              ?>
                              <tr class="unread">
                                  <td class="inbox-small-cells">
                                      <input type="checkbox" name='check[]' value='<?php echo $row['draft_id'];?>' class="mail-checkbox">
                                  </td>
                                  
                                  <td class="view-message  dont-show"><a href="HomePage.php?chk=recompose&cmpid=<?php echo $row['draft_id'];?>"><?php echo $row['sub'];?></a></td>
                                  <td class="view-message "><a href="HomePage.php?chk=recompose&cmpid=<?php echo $row['draft_id'];?>"><?php echo $mailcontent.'...';?></a></td>
                                 <td class="view-message  inbox-small-cells">
                                     <a href="<?php echo $row['attach'];?>" target="_blank"><?php if($row['attach'] !==''){ echo '<i class="fa fa-paperclip"></i>';}?></a>
                                  </td>
                                  <td class="view-message  text-right"><small></small><?php echo $row['date'];?></small></td>
                                   <td class="view-message  text-right"><a href="HomePage.php?chk=recompose&cmpid=<?php echo $row['draft_id'];?>"><i class="fa fa-eye"></i></a></td>
                              </tr>
                             <?php }}else{ echo "<center><p class='alert alert-info'>No message in draft..</p></center>";} ?>
                             
                          </tbody>
                          </table>
                          </div>
                      </div>
                  </aside>
              </div>
</div>