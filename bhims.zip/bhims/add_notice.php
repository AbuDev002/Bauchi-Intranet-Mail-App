<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Add New User";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
					<?php
					
					if(isset($_POST['btnAddNotice'])){
					$subject = $_POST['subject'];
					$content = $_POST['content'];
					$poster = $_POST['poster'];

					$subject = mysqli_real_escape_string($conms,$subject);
					$content = mysqli_real_escape_string($conms,$content);
					$poster = mysqli_real_escape_string($conms,$poster);
					
					if(empty($subject) || empty($content)){
						echo "<p class='alert alert-danger'>Please enter minute quote</p>";
					}else{
						
						include_once('connection.php');
						$addnotice_qry = mysqli_query($conms,"INSERT INTO notice (subject,notice_content,postedby) VALUES('$subject','$content','$poster')");
						if($addnotice_qry){
							echo "<p class='alert alert-success'>Posted Successfully!</p>";
						}else{
									echo "<p class='alert alert-danger'>Unable to create minute</p>";
								}
							}
						}
					
					?>
					<form action="" method="post">
						 <div class="card">
					 	<div class="card-header"><span class="fa fa-plus"></span> Create New Notice</div>
					 	<div class="card-body">
					 		<div class="form-group">
					 			<input type="text" name="subject" class="form-control" placeholder="Enter subject...">
					 		</div>
					 		<div class="form-group">
					 				<textarea class="form-control ckeditor" cols="30" rows="4" name="content" placeholder="Write notice..."></textarea>
					 		</div>
					 		<div class="form-group">
					 			<input type="hidden" name="poster" value="<?php echo $_SESSION['name'];?>">
					 		</div>
					 		<div class="form-group">
					 			<button type="submit" class="btn btn-primary margin-bottom" name="btnAddNotice"><i class="fa fa-plus"></i> Post Notice</button>
					 		</div>
					
					 	</div>
					 </div>
						
					</form>
				</div>
			</div>
			
<?php include_once('incs/footer.php');?>