
<div class="mail-box">
                <?php include_once('incs/mailbuttons.php');?>
                <div>
                  <aside class="lg-side">
                      <div class="inbox-body" style="border:1px solid silver;">
                        <br/>
                         <div class="table-responsive">
                          <table class="table table-inbox table-hover">
                            <tbody>
                              <?php

                                include_once('connection.php');
                                $id=$_SESSION['email'];
                                $sql="SELECT * FROM usermail where sen_id='$id' ORDER BY mail_id DESC";
                                $dd=mysqli_query($conms,$sql);
                                if(mysqli_num_rows($dd) >0){
                                while($row=mysqli_fetch_array($dd)){
                                	$mailcontent = substr($row['msg'],0,70);
                                  $fextension = pathinfo($row['attachement'],PATHINFO_EXTENSION);
                              ?>
                              <tr class="unread">
                                  <td class="inbox-small-cells">
                                      <input type="checkbox" name='check[]' value='<?php echo $row['mail_id'];?>' class="mail-checkbox">
                                  </td>
                                  <td class="inbox-small-cells">
                                    <?php if($row['seenstatus'] == 1){?>
                                    <!-- <i class="fa fa-star"></i> -->
                                    <a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><i class="fa fa-envelope-open-o"><small> viewed</small></i></a>
                                  <?php }else{?>
                                    <a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><span class="badge badge-secondary"><i class="fa fa-envelope"></i> New <small> Unread</small></span></a>

                                  <?php } ?>
                                  </td>
                                  <td class="view-message  dont-show"><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><?php echo $row['sub'];?></a></td>
                                  <td class="view-message "><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><?php echo $mailcontent.'...';?></a></td>
                                 <td class="view-message  inbox-small-cells">
                                     <a href="<?php echo ($fextension=='pdf')?'makeidtofile.php?fid='.$row["mail_id"]:$row["attachement"];?>" target="_blank"><?php if($row['attachement'] !==''){ echo '<i class="fa fa-paperclip"></i>';}?></a>
                                  </td>
                                  <td class="view-message  text-right"><small ><?php echo $row['recDT'];?></small></td>
                                   <td class="view-message  text-right"><a href="MailPage.php?vw=<?php echo $row['mail_id'];?>"><i class="fa fa-eye"></i></a></td>
                              </tr>
                             <?php }}else{ echo "<center><p class='alert alert-info'>No message sent..</p></center>";} ?>
                             
                          </tbody>
                          </table>
                          </div>
                      </div>
                  </aside>
              </div>
</div>