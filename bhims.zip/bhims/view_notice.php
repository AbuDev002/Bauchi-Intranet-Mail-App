<?php
session_start();
if(!isset($_SESSION['username']) || !isset($_SESSION['email'])){
	header('location:index.php');
}
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu.php');?>
			<div class="container">
				<?php include_once('incs/header.php')?>
				<div id="content">
					<table border="0" id="fimage" align="right" width="100%">
						<tr>
							<th colspan="10">Collaborative Information System</th>
						</tr>
						
					</table>
					<table border="1"  align="right" width="100%">
						<tr>
							<td align="center"><a href="function_unit.php"><button>Home</button></a></td>
							<td align="center"><a href="add_notice.php"><button>Post</button></a></td>
							<td align="center"><a href="departments.php"><button>Departments</button></a></td>
							<td align="center"><a href="view_info.php"><button>View Info</button></a></td>
							<td align="center"><a href="new_employee.php"><button>Add new Employee</button></a></td>
							<td align="center"><a href="logout.php"><button>Logout</button></a></td>
							
						</tr>
						<tr>
							
							<td colspan="10" height="400" valign="top">
								<table border="1" align="center" width="80%">
									
									<tr>
										<th colspan="8">Notice Board</th>
									</tr>
									<tr>
										<th>Subject</th>
										<th>Posted By</th>
										<th>Rank</th>
										<th>Date</th>
										<th>Notice</th>
										<th>Action</th>
									</tr>
									<?php
											foreach(get_data('notice') as $notice){
											$notice_id = $notice['notie_id'];
											$notice_subject = $notice['subject'];
											$notice_date = $notice['notice_date'];
											$notice_content = $notice['notice_content'];
											$postedby = $notice['postedby'];
											$rank = $notice['position'];
											
											
										?>
									<tr>
										<td><?php echo $notice_subject;?></td>
										<td><?php echo $postedby;?></td>
										<td><?php echo $rank;?></td>
										<td><?php echo $notice_date;?></td>
										<td><?php echo $notice_content;?></td>
										<td><a href="del_notice.php?del=<?php echo $notice_id;?>" onclick="return confirm('Are you sure to delete?')">Delete</a></td>
										
									</tr>	
									<?php }?>
								</table>
							
							
							</td>
						</tr>
						
					</table>
					
					
				</div>
			</div>
<?php include_once('incs/footer.php');?>