<?php
	include_once('connection.php');
	if(isset($_GET['del'])){
		$delete = $_GET['del'];
		$delete_query ="DELETE FROM notice WHERE notie_id ='".$delete."'";
		$query_run = mysqli_query($conms,$delete_query);
		if($query_run){
			header('location: notice_board.php');	
		}
	}
?>