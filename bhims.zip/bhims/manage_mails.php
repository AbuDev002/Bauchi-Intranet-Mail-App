<?php
session_start();
if(!isset($_SESSION['email'])){
	header('location:index.php');
}
$title ="Manage Minutes";
?>
<?php include_once('incs/head.php');?>
<?php include_once('incs/menu2.php');?>
			<div class="container">
				<?php include_once('incs/upnavbar.php');?>
				<form action="" method="post" enctype="multipart/form-data">
				<div class="row" style="background: #f5f5f5;">
					<?php include_once('incs/sidemenu.php');?>
					<div class="col-md-10" style="min-height: 500px;background:#fff;margin-top:10px;padding-top: 10px;">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<table class="table table-bordered">
									<tr>
										<td align="center">
											<?php
											if(isset($_POST['btnFlush'])){
												include_once('connection.php');
												$flush = mysqli_query($conms,"TRUNCATE usermail");
												if($flush){
													echo"<script>alert('Emails Deleted Successfully')</script>";
													echo "<script>window.open('manage_mails.php','_self')</script>";
												}
											}
											?>
											<form action="" method="post">
												<div class="form-group">
													<button onlick="return confirm('Are you sure')" type="submit"  name="btnFlush" class="btn btn-danger"><i class="fa fa-trash"></i> Clear All Mails</button>
												</div>				
											</form>
										
										</td>
										<td align="center">
											<!-- <a href="#" class="btn btn-primary margin-bottom">Back Up Database</a> -->
											<form action="backup_db.php" method="POST">
												<button class="btn btn-primary margin-bottom" type="submit" name="backup">Backup Database</button>
											</form>
										</td>
									</tr>
								</table>
								<!-- <center><p><a href="dbbackup">Download Backup</a></p></center> -->
							</div>
							<div class="col-md-3"></div>
						</div>
					
						</div>
							
					</div>
			</form>
			</div>
			
<?php include_once('incs/footer.php');?>