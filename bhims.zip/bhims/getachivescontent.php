<?php
    include_once('connection.php');
    extract($_REQUEST);
    $query = "select * from archives where archive_id=".$id;
    $description = mysqli_query($conms,$query);
    $row = mysqli_fetch_assoc($description);
    echo'<div class="card">
                  <div class="card-body">';
	echo"<hr/>";
   echo "<h4>".$row['sub']."</h4>";
    echo "<p>".$row['msg']."</p>";
    echo "<br /><b>Date:</b> <span style='font-size:12px;color:grey'>".date("d-m-Y",strtotime($row['archivedate']))."</span>";
    echo ' </div>
                  <div class="card-footer"><a href="#"><i class="fa fa-print"></i></a></div>
                </div>';
?>